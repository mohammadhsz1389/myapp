// Domain types for محراب

export type PrayerKey = "fajr" | "dhuhr" | "asr" | "maghrib" | "isha";

export type DhikrKey = "salawat" | "tawhid" | "hamd";

/** A single prayer slot inside a Qada day */
export interface PrayerSlot {
  done: boolean;
  /** epoch milliseconds when completed (real local timestamp) */
  ts: number | null;
}

/** One Qada day = a set of 5 missed prayers being made up. Indexed 0..total-1 */
export interface QadaDayState {
  prayers: Record<PrayerKey, PrayerSlot>;
}

/** Per-calendar-day dhikr counts (calendar day = Jalali/Gregorian day in user local time) */
export type DhikrDayRecord = Partial<Record<DhikrKey, number>>;

export interface UserProfile {
  totalQadaDays: number;
  /** ISO date string (YYYY-MM-DD) the user started their journey */
  startDate: string;
  /** daily goal expressed in Qada-days (1 day = 5 prayers) */
  dailyGoal: number;
  marja: string;
  createdAt: number;
}

export interface ReminderSettings {
  enabled: boolean;
  /** "HH:MM" in 24h local time */
  time: string;
  /** whether browser notification permission is granted */
  permission: "default" | "granted" | "denied" | "unsupported";
}

export interface Settings {
  theme: "light" | "dark" | "system";
  reminders: ReminderSettings;
  /** show Jalali (Persian) calendar — always true but kept for extensibility */
  jalaliCalendar: boolean;
}

/** Achievement definitions live in config; this is the persisted "ever unlocked" log */
export type AchievementId =
  | "first_step"
  | "first_full_day"
  | "streak_7"
  | "days_10"
  | "days_50"
  | "days_100"
  | "dhikr_100"
  | "dhikr_1000"
  | "halfway"
  | "complete";

export interface RootState {
  /** whether onboarding has been completed */
  onboarded: boolean;
  /** whether initial setup (profile) has been completed */
  setupComplete: boolean;
  profile: UserProfile | null;
  settings: Settings;
  /** Qada days keyed by index. Sparse — missing means untouched (all prayers undone). */
  qadaDays: Record<number, QadaDayState>;
  /** Dhikr counts keyed by calendar date "YYYY-MM-DD" */
  dhikr: Record<string, DhikrDayRecord>;
  /** Set of achievement ids ever unlocked via real activity (intentional persistence) */
  unlockedAchievements: AchievementId[];
  /** last viewed onboarding version, to allow replay */
  onboardingVersion: number;
}
