import type { AchievementId, DhikrKey, PrayerKey } from "./types";

// ───────────────────────── Prayers (Qada) ─────────────────────────
// Fixed product rules — these are genuine religious constants, not fake data.
export interface PrayerDef {
  key: PrayerKey;
  name: string;
  shortName: string;
  rakat: number; // number of rak'ahs in this prayer (Qada)
  description: string;
}

export const PRAYERS: PrayerDef[] = [
  {
    key: "fajr",
    name: "نماز صبح",
    shortName: "صبح",
    rakat: 2,
    description: "نماز صبح دو رکعتی",
  },
  {
    key: "dhuhr",
    name: "نماز ظهر",
    shortName: "ظهر",
    rakat: 4,
    description: "نماز ظهر چهار رکعتی",
  },
  {
    key: "asr",
    name: "نماز عصر",
    shortName: "عصر",
    rakat: 4,
    description: "نماز عصر چهار رکعتی",
  },
  {
    key: "maghrib",
    name: "نماز مغرب",
    shortName: "مغرب",
    rakat: 3,
    description: "نماز مغرب سه رکعتی",
  },
  {
    key: "isha",
    name: "نماز عشاء",
    shortName: "عشاء",
    rakat: 4,
    description: "نماز عشاء چهار رکعتی",
  },
];

export const PRAYER_KEYS: PrayerKey[] = PRAYERS.map((p) => p.key);

export const PRAYER_MAP: Record<PrayerKey, PrayerDef> = Object.fromEntries(
  PRAYERS.map((p) => [p.key, p]),
) as Record<PrayerKey, PrayerDef>;

export const TOTAL_RAKAT_PER_DAY = PRAYERS.reduce((s, p) => s + p.rakat, 0); // 17

// ───────────────────────── Dhikr ─────────────────────────
export interface DhikrDef {
  key: DhikrKey;
  name: string;
  arabic: string;
  /** internal application scoring value (NOT a guaranteed divine reward) */
  internalPoints: number;
  /** XP per count = internalPoints / 100 */
  description: string;
}

export const DHIKR_LIST: DhikrDef[] = [
  {
    key: "salawat",
    name: "صلوات",
    arabic: "اَللّٰهُمَّ صَلِّ عَلٰی مُحَمَّدٍ وَآلِ مُحَمَّد",
    internalPoints: 100,
    description: "فرستادن درود بر پیامبر و خاندان ایشان",
  },
  {
    key: "tawhid",
    name: "سوره توحید",
    arabic: "قُلْ هُوَ اللَّهُ أَحَدٌ ...",
    internalPoints: 1000,
    description: "خواندن سوره توحید (اخلاص)",
  },
  {
    key: "hamd",
    name: "سوره حمد",
    arabic: "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ ...",
    internalPoints: 1500,
    description: "خواندن سوره حمد (فاتحه الکتاب)",
  },
];

export const DHIKR_MAP: Record<DhikrKey, DhikrDef> = Object.fromEntries(
  DHIKR_LIST.map((d) => [d.key, d]),
) as Record<DhikrKey, DhikrDef>;

export const DHIKR_KEYS: DhikrKey[] = DHIKR_LIST.map((d) => d.key);

// ───────────────────────── XP & Levels ─────────────────────────
// XP is a DERIVED value (single source of truth). Formula (deterministic):
//   - each completed Qada prayer: +10 XP
//   - each fully completed Qada day:  +50 XP bonus (so a full day = 5×10 + 50 = 100 XP)
//   - each dhikr count:                +internalPoints/100 XP (salawat=1, tawhid=10, hamd=15)
// Because XP is derived, undoing a prayer/dhikr automatically reverses XP.
export const XP_PER_PRAYER = 10;
export const XP_BONUS_FULL_DAY = 50;

// Level thresholds (cumulative XP required to REACH each level). Calm, professional Persian names.
export interface LevelDef {
  level: number;
  xpRequired: number; // cumulative XP to reach this level
  name: string; // Persian level name
}

const RAW_LEVELS: { name: string; xp: number }[] = [
  { name: "آغاز", xp: 0 },
  { name: "گام", xp: 100 },
  { name: "استقامت", xp: 300 },
  { name: "پایداری", xp: 600 },
  { name: "وفاداری", xp: 1000 },
  { name: "همت", xp: 1500 },
  { name: "اراده", xp: 2200 },
  { name: "پختگی", xp: 3000 },
  { name: "رسایی", xp: 4000 },
  { name: "کمال", xp: 5500 },
  { name: "درخشش", xp: 7200 },
  { name: "شکوفایی", xp: 9200 },
  { name: "تعالی", xp: 11500 },
  { name: "رستگاری", xp: 14500 },
  { name: "قرب", xp: 18000 },
];

export const LEVELS: LevelDef[] = RAW_LEVELS.map((l, i) => ({
  level: i + 1,
  xpRequired: l.xp,
  name: l.name,
}));

// For XP beyond the last defined level, continue with a formula.
export function levelFromXp(xp: number): LevelDef {
  for (let i = LEVELS.length - 1; i >= 0; i--) {
    if (xp >= LEVELS[i].xpRequired) {
      // if at the top defined level, compute extended levels via formula
      if (i === LEVELS.length - 1) {
        let extra = 1;
        let threshold = LEVELS[i].xpRequired;
        let prev = threshold;
        while (xp >= threshold) {
          prev = threshold;
          threshold = LEVELS[i].xpRequired + extra * 4500 + (extra * (extra - 1)) / 2 * 500;
          if (xp < threshold) break;
          extra++;
        }
        return {
          level: LEVELS[i].level + extra - 1,
          xpRequired: prev,
          name: "مسیر روشن",
        };
      }
      return LEVELS[i];
    }
  }
  return LEVELS[0];
}

/** XP needed to reach the NEXT level from current level, and progress within current level */
export function levelProgress(xp: number) {
  const current = levelFromXp(xp);
  // find next threshold
  const nextThreshold = nextLevelXp(current.level, current.xpRequired, xp);
  const span = nextThreshold - current.xpRequired;
  const into = xp - current.xpRequired;
  const pct = span <= 0 ? 100 : Math.min(100, Math.max(0, (into / span) * 100));
  return {
    level: current.level,
    name: current.name,
    xp,
    intoLevel: into,
    levelSpan: span,
    toNext: Math.max(0, nextThreshold - xp),
    pct,
  };
}

function nextLevelXp(level: number, currentBase: number, xp: number): number {
  const idx = LEVELS.findIndex((l) => l.level === level);
  if (idx >= 0 && idx + 1 < LEVELS.length) {
    return LEVELS[idx + 1].xpRequired;
  }
  // extended formula
  if (idx === LEVELS.length - 1) {
    const extra = level - LEVELS.length + 1;
    return (
      currentBase +
      (extra + 1) * 4500 +
      ((extra + 1) * extra) / 2 * 500
    );
  }
  // fallback
  return currentBase + 4500;
}

// ───────────────────────── Achievements ─────────────────────────
// All derived from real data. None unlocked by default.
export interface AchievementDef {
  id: AchievementId;
  title: string;
  description: string;
  icon: string; // lucide icon name
}

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: "first_step",
    title: "اولین قدم",
    description: "اولین نماز قضای خود را کامل کن.",
    icon: "Footprints",
  },
  {
    id: "first_full_day",
    title: "اولین روز کامل",
    description: "یک روز کامل قضا (پنج نماز) را به پایان برسان.",
    icon: "CheckCircle2",
  },
  {
    id: "streak_7",
    title: "۷ روز متوالی",
    description: "هفت روز پیاپی هدف روزانه خود را محقق کن.",
    icon: "Flame",
  },
  {
    id: "days_10",
    title: "۱۰ روز قضا",
    description: "ده روز کامل قضا را به پایان برسان.",
    icon: "CalendarCheck",
  },
  {
    id: "days_50",
    title: "۵۰ روز قضا",
    description: "پنجاه روز کامل قضا را به پایان برسان.",
    icon: "Medal",
  },
  {
    id: "days_100",
    title: "۱۰۰ روز قضا",
    description: "صد روز کامل قضا را به پایان برسان.",
    icon: "Award",
  },
  {
    id: "dhikr_100",
    title: "ذاکر",
    description: "مجموعاً صد ذکر تکرار کن.",
    icon: "Sparkles",
  },
  {
    id: "dhikr_1000",
    title: "کثیرالذکر",
    description: "مجموعاً هزار ذکر تکرار کن.",
    icon: "Star",
  },
  {
    id: "halfway",
    title: "نیمه‌راه",
    description: "به پنجاه درصد پیشرفت کلی برس.",
    icon: "Flag",
  },
  {
    id: "complete",
    title: "تکمیل",
    description: "تمام نمازهای قضای خود را به پایان برسان.",
    icon: "Trophy",
  },
];

export const ACHIEVEMENT_MAP: Record<AchievementId, AchievementDef> =
  Object.fromEntries(ACHIEVEMENTS.map((a) => [a.id, a])) as Record<
    AchievementId,
    AchievementDef
  >;

// ───────────────────────── Marja options ─────────────────────────
// We make NO fiqh claims. This is just an optional personal reference label.
export const MARJA_OPTIONS: string[] = [
  "بدون مرجع",
  "حضرت آیت‌الله العظمی سیستانی",
  "حضرت آیت‌الله العظمی مکارم شیرازی",
  "حضرت آیت‌الله العظمی وحید خراسانی",
  "حضرت آیت‌الله العظمی صافی گلپایگانی",
  "حضرت آیت‌الله العظمی جوادی آملی",
  "سایر",
];

// ───────────────────────── Daily goal options ─────────────────────────
// expressed in Qada-days per day (1 day = 5 prayers)
export const DAILY_GOAL_OPTIONS: { value: number; label: string }[] = [
  { value: 1, label: "۱ روز در روز (۵ نماز)" },
  { value: 2, label: "۲ روز در روز (۱۰ نماز)" },
  { value: 3, label: "۳ روز در روز (۱۵ نماز)" },
];

export const APP_VERSION = "۱.۰.۰";
export const ONBOARDING_VERSION = 1;
