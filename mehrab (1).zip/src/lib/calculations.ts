import {
  ACHIEVEMENTS,
  DHIKR_KEYS,
  DHIKR_MAP,
  PRAYERS,
  PRAYER_KEYS,
  XP_BONUS_FULL_DAY,
  XP_PER_PRAYER,
  levelProgress,
} from "./config";
import {
  addDays,
  daysBetween,
  isoDate,
  toJalaali,
} from "./persian";
import type { RootState } from "./types";
import type { AchievementId, DhikrKey, PrayerKey } from "./types";
import { isDayComplete } from "./store";

// ───────────────────────── Qada core stats ─────────────────────────

export interface PrayerCompletion {
  dayIndex: number;
  prayer: PrayerKey;
  ts: number;
}

/** All individual prayer completion events (newest first), with real timestamps. */
export function prayerCompletions(state: RootState): PrayerCompletion[] {
  const out: PrayerCompletion[] = [];
  for (const key of Object.keys(state.qadaDays)) {
    const idx = Number(key);
    const day = state.qadaDays[idx];
    for (const p of PRAYER_KEYS) {
      const slot = day.prayers[p];
      if (slot?.done && slot.ts != null) {
        out.push({ dayIndex: idx, prayer: p, ts: slot.ts });
      }
    }
  }
  out.sort((a, b) => b.ts - a.ts);
  return out;
}

export function completedPrayerCount(state: RootState): number {
  let n = 0;
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      if (day.prayers[p]?.done) n++;
    }
  }
  return n;
}

export function completedDayCount(state: RootState): number {
  let n = 0;
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    if (isDayComplete(day)) n++;
  }
  return n;
}

export function totalQadaDays(state: RootState): number {
  return state.profile?.totalQadaDays ?? 0;
}

export function remainingDays(state: RootState): number {
  return Math.max(0, totalQadaDays(state) - completedDayCount(state));
}

export function overallProgress(state: RootState): number {
  const total = totalQadaDays(state);
  if (total <= 0) return 0;
  return Math.min(100, Math.max(0, (completedDayCount(state) / total) * 100));
}

/** Active (first incomplete) qada day index. Returns -1 if journey complete. */
export function activeDayIndex(state: RootState): number {
  const total = totalQadaDays(state);
  for (let i = 0; i < total; i++) {
    const day = state.qadaDays[i];
    if (!day || !isDayComplete(day)) return i;
  }
  return -1;
}

export function dayCompletionRatio(dayIndex: number, state: RootState): number {
  const day = state.qadaDays[dayIndex];
  if (!day) return 0;
  return PRAYER_KEYS.filter((k) => day.prayers[k]?.done).length;
}

// ───────────────────────── XP / Level ─────────────────────────

export function xpFromQada(state: RootState): number {
  const prayers = completedPrayerCount(state);
  const fullDays = completedDayCount(state);
  return prayers * XP_PER_PRAYER + fullDays * XP_BONUS_FULL_DAY;
}

export function xpFromDhikr(state: RootState): number {
  let xp = 0;
  for (const date of Object.keys(state.dhikr)) {
    const day = state.dhikr[date];
    if (!day) continue;
    for (const k of DHIKR_KEYS) {
      const count = day[k] ?? 0;
      xp += count * (DHIKR_MAP[k].internalPoints / 100);
    }
  }
  return Math.round(xp);
}

export function totalXp(state: RootState): number {
  return xpFromQada(state) + xpFromDhikr(state);
}

export function levelInfo(state: RootState) {
  return levelProgress(totalXp(state));
}

// ───────────────────────── Dhikr stats ─────────────────────────

export function totalDhikrCount(state: RootState): number {
  let n = 0;
  for (const date of Object.keys(state.dhikr)) {
    const day = state.dhikr[date];
    if (!day) continue;
    for (const k of DHIKR_KEYS) n += day[k] ?? 0;
  }
  return n;
}

export function dhikrCountByType(state: RootState): Record<DhikrKey, number> {
  const out: Record<DhikrKey, number> = {
    salawat: 0,
    tawhid: 0,
    hamd: 0,
  };
  for (const date of Object.keys(state.dhikr)) {
    const day = state.dhikr[date];
    if (!day) continue;
    for (const k of DHIKR_KEYS) out[k] += day[k] ?? 0;
  }
  return out;
}

export function dhikrCountToday(state: RootState): number {
  const today = isoDate(new Date());
  const day = state.dhikr[today];
  if (!day) return 0;
  let n = 0;
  for (const k of DHIKR_KEYS) n += day[k] ?? 0;
  return n;
}

export function dhikrInternalPoints(state: RootState): number {
  let p = 0;
  const counts = dhikrCountByType(state);
  for (const k of DHIKR_KEYS) {
    p += counts[k] * DHIKR_MAP[k].internalPoints;
  }
  return p;
}

// ───────────────────────── Rak'ahs ─────────────────────────

export function totalRakat(state: RootState): number {
  const counts = prayerCountsByType(state);
  let n = 0;
  for (const p of PRAYERS) {
    n += counts[p.key] * p.rakat;
  }
  return n;
}

export function prayerCountsByType(
  state: RootState,
): Record<PrayerKey, number> {
  const out: Record<PrayerKey, number> = {
    fajr: 0,
    dhuhr: 0,
    asr: 0,
    maghrib: 0,
    isha: 0,
  };
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      if (day.prayers[p]?.done) out[p]++;
    }
  }
  return out;
}

// ───────────────────────── Streak ─────────────────────────
// A calendar day "goal-met" when prayers completed THAT DAY (by timestamp) >= dailyGoal*5.
// Streak = consecutive calendar days (ending today or yesterday) with goal met.

function prayersOnDate(state: RootState, dateStr: string): number {
  let n = 0;
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      const slot = day.prayers[p];
      if (slot?.done && slot.ts != null) {
        if (isoDate(new Date(slot.ts)) === dateStr) n++;
      }
    }
  }
  return n;
}

export function dailyGoalTarget(state: RootState): number {
  return (state.profile?.dailyGoal ?? 1) * 5;
}

export function prayersToday(state: RootState): number {
  return prayersOnDate(state, isoDate(new Date()));
}

/** is a given calendar date a "goal met" day */
export function isGoalMetDate(state: RootState, dateStr: string): boolean {
  return prayersOnDate(state, dateStr) >= dailyGoalTarget(state);
}

export function currentStreak(state: RootState): number {
  let streak = 0;
  const today = new Date();
  // if today not yet met, streak may be continuing from yesterday
  let cursor = new Date(today);
  // allow streak to count if today met OR yesterday met (today may not be over yet)
  if (!isGoalMetDate(state, isoDate(cursor))) {
    cursor = addDays(cursor, -1);
    if (!isGoalMetDate(state, isoDate(cursor))) return 0;
  }
  // count back consecutive goal-met days
  while (isGoalMetDate(state, isoDate(cursor))) {
    streak++;
    cursor = addDays(cursor, -1);
  }
  return streak;
}

export function longestStreak(state: RootState): number {
  const dates = new Set<string>();
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      const slot = day.prayers[p];
      if (slot?.done && slot.ts != null) {
        dates.add(isoDate(new Date(slot.ts)));
      }
    }
  }
  const sorted = Array.from(dates).sort();
  let longest = 0;
  let run = 0;
  let prev: Date | null = null;
  for (const d of sorted) {
    const date = new Date(d);
    if (prev && daysBetween(prev, date) === 1) {
      run++;
    } else {
      run = 1;
    }
    // only count as a streak day if goal met on that date
    if (isGoalMetDate(state, d)) {
      longest = Math.max(longest, run);
    } else {
      run = 0;
    }
    prev = date;
  }
  return longest;
}

// ───────────────────────── Calendar ─────────────────────────

export type CalendarDayStatus = "none" | "partial" | "complete";

export interface CalendarDayInfo {
  date: string;
  status: CalendarDayStatus;
  prayerCount: number;
}

export function calendarDayStatus(
  state: RootState,
  dateStr: string,
): CalendarDayInfo {
  const n = prayersOnDate(state, dateStr);
  const target = dailyGoalTarget(state);
  let status: CalendarDayStatus = "none";
  if (n > 0 && n >= target) status = "complete";
  else if (n > 0) status = "partial";
  return { date: dateStr, status, prayerCount: n };
}

// ───────────────────────── History ─────────────────────────

export interface HistoryEntry {
  id: string;
  kind: "prayer" | "dhikr";
  // prayer
  dayIndex?: number;
  prayer?: PrayerKey;
  // dhikr
  dhikrType?: DhikrKey;
  dhikrCount?: number;
  ts: number;
  label: string;
}

export function historyEntries(state: RootState): HistoryEntry[] {
  const out: HistoryEntry[] = [];
  for (const c of prayerCompletions(state)) {
    const def = PRAYERS.find((p) => p.key === c.prayer)!;
    out.push({
      id: `p-${c.dayIndex}-${c.prayer}`,
      kind: "prayer",
      dayIndex: c.dayIndex,
      prayer: c.prayer,
      ts: c.ts,
      label: `نماز ${def.shortName} (روز قضای ${c.dayIndex + 1})`,
    });
  }
  // dhikr: one aggregate per day per type
  for (const date of Object.keys(state.dhikr)) {
    const day = state.dhikr[date];
    if (!day) continue;
    for (const k of DHIKR_KEYS) {
      const count = day[k] ?? 0;
      if (count > 0) {
        // use end of that day as ts for ordering
        const ts = new Date(date + "T23:59:59").getTime();
        out.push({
          id: `d-${date}-${k}`,
          kind: "dhikr",
          dhikrType: k,
          dhikrCount: count,
          ts,
          label: `${DHIKR_MAP[k].name}: ${count} مرتبه`,
        });
      }
    }
  }
  out.sort((a, b) => b.ts - a.ts);
  return out;
}

// ───────────────────────── Achievements ─────────────────────────

/** Returns the set of achievement ids that CURRENTLY meet their condition. */
export function currentlyMetAchievements(state: RootState): Set<AchievementId> {
  const met = new Set<AchievementId>();
  const prayers = completedPrayerCount(state);
  const fullDays = completedDayCount(state);
  const progress = overallProgress(state);
  const longest = longestStreak(state);
  const current = currentStreak(state);
  const dhikrTotal = totalDhikrCount(state);

  if (prayers >= 1) met.add("first_step");
  if (fullDays >= 1) met.add("first_full_day");
  if (current >= 7 || longest >= 7) met.add("streak_7");
  if (fullDays >= 10) met.add("days_10");
  if (fullDays >= 50) met.add("days_50");
  if (fullDays >= 100) met.add("days_100");
  if (dhikrTotal >= 100) met.add("dhikr_100");
  if (dhikrTotal >= 1000) met.add("dhikr_1000");
  if (progress >= 50) met.add("halfway");
  if (fullDays >= totalQadaDays(state) && totalQadaDays(state) > 0)
    met.add("complete");
  return met;
}

/** Returns true if achievement id was ever unlocked (persisted). */
export function isAchievementEverUnlocked(
  state: RootState,
  id: AchievementId,
): boolean {
  return state.unlockedAchievements.includes(id);
}

export function newlyUnlockedAchievements(
  state: RootState,
): AchievementId[] {
  const met = currentlyMetAchievements(state);
  const out: AchievementId[] = [];
  for (const a of ACHIEVEMENTS) {
    if (met.has(a.id) && !state.unlockedAchievements.includes(a.id)) {
      out.push(a.id);
    }
  }
  return out;
}

// ───────────────────────── Personal Path ─────────────────────────

export interface PathMilestone {
  label: string;
  daysRemaining: number; // days remaining at this milestone
  isReached: boolean;
  isCurrent: boolean;
}

/** Build a dynamic personal path from the user's actual total. */
export function personalPath(state: RootState): PathMilestone[] {
  const total = totalQadaDays(state);
  const remaining = remainingDays(state);
  if (total <= 0) return [];
  const milestones: PathMilestone[] = [];
  // Start point
  milestones.push({
    label: "شروع",
    daysRemaining: total,
    isReached: remaining <= total,
    isCurrent: false,
  });
  // pick round milestones depending on total magnitude
  const steps = pathSteps(total);
  for (const s of steps) {
    if (s >= total) continue;
    milestones.push({
      label: `۰ تا ${s}`,
      daysRemaining: total - s,
      isReached: remaining <= total - s,
      isCurrent: false,
    });
  }
  // Finish
  milestones.push({
    label: "پایان",
    daysRemaining: 0,
    isReached: remaining <= 0,
    isCurrent: remaining <= 0,
  });
  // mark current pointer
  for (let i = 0; i < milestones.length; i++) {
    if (remaining > milestones[i].daysRemaining) {
      milestones[i].isCurrent = true;
      break;
    }
  }
  // if remaining is exactly a milestone's value, mark that one current
  for (let i = milestones.length - 1; i >= 0; i--) {
    if (remaining === milestones[i].daysRemaining && remaining !== 0) {
      milestones.forEach((m) => (m.isCurrent = false));
      milestones[i].isCurrent = true;
      break;
    }
  }
  return milestones;
}

function pathSteps(total: number): number[] {
  if (total <= 10) return [5, 10];
  if (total <= 50) return [10, 20, 30, 40, 50];
  if (total <= 100) return [25, 50, 75, 100];
  if (total <= 300) return [50, 100, 150, 200, 250, 300];
  if (total <= 500) return [100, 200, 300, 400, 500];
  // round to nearest 100
  const out: number[] = [];
  for (let s = 100; s <= total; s += 100) out.push(s);
  if (out[out.length - 1] !== total) out.push(total);
  return out;
}

// ───────────────────────── Completion Estimation ─────────────────────────

export interface Estimation {
  hasEnoughData: boolean;
  reason?: string;
  estimatedFinishDate?: Date;
  estimatedDaysLeft?: number;
  avgPrayersPerDay?: number;
}

/** Need at least 3 distinct active days to estimate a trend. */
export function estimation(state: RootState): Estimation {
  const total = totalQadaDays(state);
  const remaining = remainingDays(state);
  if (total <= 0 || remaining <= 0) {
    return { hasEnoughData: false, reason: "تکمیل شده است." };
  }
  // gather distinct active days
  const activeDates = new Set<string>();
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      const slot = day.prayers[p];
      if (slot?.done && slot.ts != null) {
        activeDates.add(isoDate(new Date(slot.ts)));
      }
    }
  }
  if (activeDates.size < 3) {
    return {
      hasEnoughData: false,
      reason: "برای محاسبه روند، ابتدا چند فعالیت ثبت کن.",
    };
  }
  // average over the last 14 active days (or all active days if fewer)
  const sortedDates = Array.from(activeDates).sort();
  const recent = sortedDates.slice(-14);
  let prayersInRecent = 0;
  for (const d of recent) prayersInRecent += prayersOnDate(state, d);
  const span = Math.max(
    1,
    daysBetween(new Date(recent[0]), new Date(recent[recent.length - 1])) + 1,
  );
  const avg = prayersInRecent / span;
  if (avg <= 0) {
    return {
      hasEnoughData: false,
      reason: "برای محاسبه روند، ابتدا چند فعالیت ثبت کن.",
    };
  }
  const prayersLeft = remaining * 5;
  const daysLeft = Math.ceil(prayersLeft / avg);
  const finish = addDays(new Date(), daysLeft);
  return {
    hasEnoughData: true,
    estimatedFinishDate: finish,
    estimatedDaysLeft: daysLeft,
    avgPrayersPerDay: avg,
  };
}

// ───────────────────────── Activity series (charts) ─────────────────────────

export interface DayActivity {
  date: string;
  jalaali: { jy: number; jm: number; jd: number };
  label: string;
  prayers: number;
  goalMet: boolean;
}

/** Last N calendar days activity (oldest first). */
export function recentActivity(state: RootState, days: number): DayActivity[] {
  const out: DayActivity[] = [];
  const today = new Date();
  const target = dailyGoalTarget(state);
  for (let i = days - 1; i >= 0; i--) {
    const d = addDays(today, -i);
    const ds = isoDate(d);
    const n = prayersOnDate(state, ds);
    out.push({
      date: ds,
      jalaali: toJalaali(d),
      label: `${d.getDate()}`,
      prayers: n,
      goalMet: n >= target,
    });
  }
  return out;
}

export function weeklyActivity(state: RootState): DayActivity[] {
  return recentActivity(state, 7);
}

export function monthlyActivity(state: RootState): DayActivity[] {
  return recentActivity(state, 30);
}

// ───────────────────────── Best day ─────────────────────────

export function bestDay(state: RootState): { date: string; prayers: number } | null {
  const counts: Record<string, number> = {};
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      const slot = day.prayers[p];
      if (slot?.done && slot.ts != null) {
        const ds = isoDate(new Date(slot.ts));
        counts[ds] = (counts[ds] ?? 0) + 1;
      }
    }
  }
  let best: { date: string; prayers: number } | null = null;
  for (const d of Object.keys(counts)) {
    if (!best || counts[d] > best.prayers) {
      best = { date: d, prayers: counts[d] };
    }
  }
  return best;
}

export function activeDaysCount(state: RootState): number {
  const set = new Set<string>();
  for (const key of Object.keys(state.qadaDays)) {
    const day = state.qadaDays[Number(key)];
    for (const p of PRAYER_KEYS) {
      const slot = day.prayers[p];
      if (slot?.done && slot.ts != null) {
        set.add(isoDate(new Date(slot.ts)));
      }
    }
  }
  return set.size;
}
