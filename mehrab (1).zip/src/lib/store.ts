import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type {
  AchievementId,
  DhikrKey,
  PrayerKey,
  QadaDayState,
  ReminderSettings,
  RootState,
  Settings,
  UserProfile,
} from "./types";
import {
  DHIKR_MAP,
  ONBOARDING_VERSION,
  PRAYER_KEYS,
  XP_BONUS_FULL_DAY,
  XP_PER_PRAYER,
} from "./config";
import { parseFaInt } from "./persian";

// ───────────────────────── Helpers ─────────────────────────
function emptyDay(): QadaDayState {
  const prayers = {} as Record<PrayerKey, { done: boolean; ts: number | null }>;
  for (const k of PRAYER_KEYS) {
    prayers[k] = { done: false, ts: null };
  }
  return { prayers };
}

function ensureDay(
  state: RootState,
  index: number,
): QadaDayState {
  if (!state.qadaDays[index]) {
    return emptyDay();
  }
  // ensure all prayer keys exist (forward compat)
  const day = state.qadaDays[index];
  const complete = { ...day.prayers };
  for (const k of PRAYER_KEYS) {
    if (!complete[k]) complete[k] = { done: false, ts: null };
  }
  return { prayers: complete };
}

function isDayComplete(day: QadaDayState): boolean {
  return PRAYER_KEYS.every((k) => day.prayers[k]?.done === true);
}

// ───────────────────────── Store ─────────────────────────
interface Actions {
  completeOnboarding: () => void;
  setupProfile: (profile: {
    totalQadaDays: number;
    startDate: string;
    dailyGoal: number;
    marja: string;
  }) => void;
  updateProfile: (patch: Partial<UserProfile>) => void;
  updateSettings: (patch: Partial<Settings>) => void;
  setReminder: (patch: Partial<ReminderSettings>) => void;
  // Qada
  togglePrayer: (dayIndex: number, prayer: PrayerKey) => void;
  setPrayer: (dayIndex: number, prayer: PrayerKey, done: boolean) => void;
  clearDay: (dayIndex: number) => void;
  // Dhikr
  incrementDhikr: (type: DhikrKey) => void;
  decrementDhikr: (type: DhikrKey) => void;
  resetDhikrDay: (date: string, type: DhikrKey) => void;
  // Achievements (auto-managed)
  syncAchievements: (ids: AchievementId[]) => void;
  // Reset
  resetAll: () => void;
  replayOnboarding: () => void;
}

export type Store = RootState & Actions;

const defaultSettings: Settings = {
  theme: "system",
  reminders: {
    enabled: false,
    time: "12:00",
    permission:
      typeof Notification !== "undefined" ? Notification.permission : "default",
  },
  jalaliCalendar: true,
};

const initialState: RootState = {
  onboarded: false,
  setupComplete: false,
  profile: null,
  settings: defaultSettings,
  qadaDays: {},
  dhikr: {},
  unlockedAchievements: [],
  onboardingVersion: 0,
};

export const useStore = create<Store>()(
  persist(
    (set, get) => ({
      ...initialState,

      completeOnboarding: () =>
        set({ onboarded: true, onboardingVersion: ONBOARDING_VERSION }),

      setupProfile: ({ totalQadaDays, startDate, dailyGoal, marja }) => {
        const total = Math.max(1, Math.floor(totalQadaDays));
        // clamp qadaDays to new total
        const qadaDays = { ...get().qadaDays };
        for (const k of Object.keys(qadaDays)) {
          const idx = Number(k);
          if (idx >= total) delete qadaDays[idx];
        }
        const profile: UserProfile = {
          totalQadaDays: total,
          startDate,
          dailyGoal: Math.max(1, Math.floor(dailyGoal)),
          marja,
          createdAt: Date.now(),
        };
        set({
          profile,
          setupComplete: true,
          qadaDays,
        });
      },

      updateProfile: (patch) => {
        const cur = get().profile;
        if (!cur) return;
        const next = { ...cur, ...patch };
        if (patch.totalQadaDays !== undefined) {
          const total = Math.max(1, Math.floor(patch.totalQadaDays));
          next.totalQadaDays = total;
          const qadaDays = { ...get().qadaDays };
          for (const k of Object.keys(qadaDays)) {
            const idx = Number(k);
            if (idx >= total) delete qadaDays[idx];
          }
          set({ profile: next, qadaDays });
          return;
        }
        set({ profile: next });
      },

      updateSettings: (patch) => {
        set({ settings: { ...get().settings, ...patch } });
      },

      setReminder: (patch) => {
        const cur = get().settings.reminders;
        set({
          settings: {
            ...get().settings,
            reminders: { ...cur, ...patch },
          },
        });
      },

      // ── Qada ──
      togglePrayer: (dayIndex, prayer) => {
        const profile = get().profile;
        if (!profile) return;
        if (dayIndex < 0 || dayIndex >= profile.totalQadaDays) return;
        const day = ensureDay(get(), dayIndex);
        const cur = day.prayers[prayer];
        const nextDone = !cur.done;
        const updatedDay: QadaDayState = {
          prayers: {
            ...day.prayers,
            [prayer]: {
              done: nextDone,
              ts: nextDone ? Date.now() : null,
            },
          },
        };
        set({
          qadaDays: { ...get().qadaDays, [dayIndex]: updatedDay },
        });
      },

      setPrayer: (dayIndex, prayer, done) => {
        const profile = get().profile;
        if (!profile) return;
        if (dayIndex < 0 || dayIndex >= profile.totalQadaDays) return;
        const day = ensureDay(get(), dayIndex);
        const cur = day.prayers[prayer];
        if (cur.done === done) return; // no-op, prevents duplicate records
        const updatedDay: QadaDayState = {
          prayers: {
            ...day.prayers,
            [prayer]: {
              done,
              ts: done ? Date.now() : null,
            },
          },
        };
        set({
          qadaDays: { ...get().qadaDays, [dayIndex]: updatedDay },
        });
      },

      clearDay: (dayIndex) => {
        const profile = get().profile;
        if (!profile) return;
        if (dayIndex < 0 || dayIndex >= profile.totalQadaDays) return;
        const qadaDays = { ...get().qadaDays };
        delete qadaDays[dayIndex];
        set({ qadaDays });
      },

      // ── Dhikr ──
      incrementDhikr: (type) => {
        const key = new Date().toISOString().slice(0, 10);
        const dhikr = { ...get().dhikr };
        const day = { ...(dhikr[key] ?? {}) };
        day[type] = (day[type] ?? 0) + 1;
        dhikr[key] = day;
        set({ dhikr });
      },

      decrementDhikr: (type) => {
        const key = new Date().toISOString().slice(0, 10);
        const dhikr = { ...get().dhikr };
        const day = { ...(dhikr[key] ?? {}) };
        const cur = day[type] ?? 0;
        if (cur <= 0) return; // never negative
        day[type] = cur - 1;
        dhikr[key] = day;
        set({ dhikr });
      },

      resetDhikrDay: (date, type) => {
        const dhikr = { ...get().dhikr };
        const day = { ...(dhikr[date] ?? {}) };
        delete day[type];
        dhikr[date] = day;
        set({ dhikr });
      },

      // ── Achievements ──
      syncAchievements: (ids) => {
        const cur = new Set(get().unlockedAchievements);
        let changed = false;
        for (const id of ids) {
          if (!cur.has(id)) {
            cur.add(id);
            changed = true;
          }
        }
        if (changed) {
          set({ unlockedAchievements: Array.from(cur) });
        }
      },

      // ── Reset ──
      resetAll: () => {
        set({
          ...initialState,
          settings: defaultSettings,
        });
      },

      replayOnboarding: () => {
        set({ onboarded: false, onboardingVersion: 0 });
      },
    }),
    {
      name: "mehrab-store-v1",
      storage: createJSONStorage(() => localStorage),
      version: 1,
      // only persist state, not actions (actions are re-created on load)
      partialize: (s) => ({
        onboarded: s.onboarded,
        setupComplete: s.setupComplete,
        profile: s.profile,
        settings: s.settings,
        qadaDays: s.qadaDays,
        dhikr: s.dhikr,
        unlockedAchievements: s.unlockedAchievements,
        onboardingVersion: s.onboardingVersion,
      }),
    },
  ),
);

// Re-export helpers used by components
export { ensureDay, isDayComplete, emptyDay };
