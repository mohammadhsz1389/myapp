// Persian utilities: Jalali calendar conversion + digit/number formatting
// Uses the well-tested `jalaali-js` package for conversion correctness.

import * as jalaali from "jalaali-js";

interface JalaaliDate {
  jy: number;
  jm: number;
  jd: number;
}
interface GregorianDate {
  gy: number;
  gm: number;
  gd: number;
}

/** Convert a JS Date (local) to Jalaali {jy, jm, jd} */
export function toJalaali(date: Date): JalaaliDate {
  return jalaali.toJalaali(date);
}

/** Convert Jalaali date to JS Date (local midnight) */
export function jalaaliToDate(jy: number, jm: number, jd: number): Date {
  const g = jalaali.toGregorian(jy, jm, jd);
  return new Date(g.gy, g.gm - 1, g.gd);
}

export function isJalaaliLeap(jy: number): boolean {
  return jalaali.isLeapJalaaliYear(jy);
}

/** Number of days in a Jalali month (1..12). */
export function jalaaliMonthLength(jy: number, jm: number): number {
  return jalaali.jalaaliMonthLength(jy, jm);
}

// ───────────────────── Formatting ─────────────────────
export const PERSIAN_MONTHS = [
  "فروردین",
  "اردیبهشت",
  "خرداد",
  "تیر",
  "مرداد",
  "شهریور",
  "مهر",
  "آبان",
  "آذر",
  "دی",
  "بهمن",
  "اسفند",
];

export const WEEKDAYS_FA = [
  "یکشنبه",
  "دوشنبه",
  "سه‌شنبه",
  "چهارشنبه",
  "پنجشنبه",
  "جمعه",
  "شنبه",
];

export const WEEKDAYS_SHORT_FA = ["ی", "د", "س", "چ", "پ", "ج", "ش"];

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

/** Convert any number/string to Persian digits */
export function toFa(input: number | string): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[+d]);
}

/** Format a number with thousands separators in Persian digits */
export function faNumber(n: number): string {
  if (!isFinite(n)) return "۰";
  const rounded = Math.round(n);
  return toFa(rounded.toLocaleString("en-US"));
}

/** Convert Persian/Arabic digits in a string back to English numbers */
export function fromFa(input: string): string {
  const map: Record<string, string> = {
    "۰": "0",
    "۱": "1",
    "۲": "2",
    "۳": "3",
    "۴": "4",
    "۵": "5",
    "۶": "6",
    "۷": "7",
    "۸": "8",
    "۹": "9",
    "٠": "0",
    "١": "1",
    "٢": "2",
    "٣": "3",
    "٤": "4",
    "٥": "5",
    "٦": "6",
    "٧": "7",
    "٨": "8",
    "٩": "9",
  };
  return input.replace(/[۰-۹٠-٩]/g, (d) => map[d] ?? d);
}

/** Parse a (possibly Persian) integer string */
export function parseFaInt(input: string): number {
  const cleaned = fromFa(input).replace(/[^\d-]/g, "");
  if (cleaned === "" || cleaned === "-") return NaN;
  return parseInt(cleaned, 10);
}

/** "YYYY-MM-DD" for a JS Date (local) */
export function isoDate(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

export function todayIso(): string {
  return isoDate(new Date());
}

/** Jalali date string "۱۴۰۳/۰۵/۱۲" */
export function jalaaliStr(date: Date): string {
  const j = toJalaali(date);
  return `${toFa(j.jy)}/${toFa(String(j.jm).padStart(2, "0"))}/${toFa(
    String(j.jd).padStart(2, "0"),
  )}`;
}

/** "۱۲ مرداد ۱۴۰۳" */
export function jalaaliLong(date: Date): string {
  const j = toJalaali(date);
  return `${toFa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]} ${toFa(j.jy)}`;
}

/** "پنجشنبه ۱۲ مرداد" */
export function jalaaliWeekdayDayMonth(date: Date): string {
  const j = toJalaali(date);
  const wd = date.getDay();
  return `${WEEKDAYS_FA[wd]} ${toFa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]}`;
}

/** "۱۲ مرداد" */
export function jalaaliDayMonth(date: Date): string {
  const j = toJalaali(date);
  return `${toFa(j.jd)} ${PERSIAN_MONTHS[j.jm - 1]}`;
}

/** Format a time-of-day as "۱۴:۳۲" in Persian digits, local time */
export function faTime(ts: number): string {
  const d = new Date(ts);
  const h = String(d.getHours()).padStart(2, "0");
  const m = String(d.getMinutes()).padStart(2, "0");
  return toFa(`${h}:${m}`);
}

/** Format a full timestamp as "۱۲ مرداد ۱۴۰۳ - ۱۴:۳۲" */
export function faDateTime(ts: number): string {
  return `${jalaaliLong(new Date(ts))} - ${faTime(ts)}`;
}

/** Days between two calendar dates (date-only, ignoring time) */
export function daysBetween(a: Date, b: Date): number {
  const ms = 1000 * 60 * 60 * 24;
  const aMid = new Date(a.getFullYear(), a.getMonth(), a.getDate());
  const bMid = new Date(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.round((bMid.getTime() - aMid.getTime()) / ms);
}

/** Add days to a date (returns new Date) */
export function addDays(date: Date, days: number): Date {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

/** Start of the Jalali week (Saturday) for a given date */
export function startOfJalaaliWeek(date: Date): Date {
  const d = new Date(date);
  const wd = d.getDay(); // 0 Sun .. 6 Sat
  // In Persian week, Saturday is the first day.
  // JS getDay: Sat=6, Sun=0, Mon=1...
  const diff = (wd + 1) % 7; // days since Saturday
  d.setDate(d.getDate() - diff);
  d.setHours(0, 0, 0, 0);
  return d;
}

/** "x روز پیش" / "x هفته پیش" etc relative */
export function relativeTime(ts: number): string {
  const now = Date.now();
  const diff = now - ts;
  const sec = Math.floor(diff / 1000);
  if (sec < 60) return "لحظاتی پیش";
  const min = Math.floor(sec / 60);
  if (min < 60) return `${toFa(min)} دقیقه پیش`;
  const hr = Math.floor(min / 60);
  if (hr < 24) return `${toFa(hr)} ساعت پیش`;
  const day = Math.floor(hr / 24);
  if (day < 30) return `${toFa(day)} روز پیش`;
  const month = Math.floor(day / 30);
  if (month < 12) return `${toFa(month)} ماه پیش`;
  const year = Math.floor(month / 12);
  return `${toFa(year)} سال پیش`;
}
