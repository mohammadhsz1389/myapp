"use client";

import * as React from "react";
import { useStore } from "@/lib/store";
import { newlyUnlockedAchievements } from "@/lib/calculations";
import { ACHIEVEMENT_MAP } from "@/lib/config";
import { toast } from "sonner";

/**
 * Watches the store for newly-met achievements and persists them (ever-unlocked),
 * surfacing a toast. This is real, intentional persistence — an achievement is only
 * ever added after its condition is genuinely met by real activity.
 */
export function useAchievementsSync() {
  const state = useStore();
  React.useEffect(() => {
    const fresh = newlyUnlockedAchievements(state);
    if (fresh.length > 0) {
      // persist
      state.syncAchievements(fresh);
      for (const id of fresh) {
        const def = ACHIEVEMENT_MAP[id];
        if (def) {
          toast.success("دستاورد جدید!", {
            description: `${def.title} — ${def.description}`,
            duration: 4500,
          });
        }
      }
    }
  }, [
    state.qadaDays,
    state.dhikr,
    state.profile,
    state.unlockedAchievements,
  ]);
}
