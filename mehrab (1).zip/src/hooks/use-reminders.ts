"use client";

import * as React from "react";
import { useStore } from "@/lib/store";

/**
 * Real reminder implementation using the browser Notification API.
 * Arms a timer that fires at the user's chosen local time while the app is open.
 * If permission isn't granted, no notification is shown (the setting still
 * records the user's intent, and we surface the permission state honestly in UI).
 */
export function useReminders() {
  const reminders = useStore((s) => s.settings.reminders);

  React.useEffect(() => {
    if (!reminders.enabled) return;
    if (reminders.permission !== "granted") return;

    let timer: ReturnType<typeof setTimeout>;
    function arm() {
      const [h, m] = reminders.time.split(":").map((x) => parseInt(x, 10));
      if (isNaN(h) || isNaN(m)) return;
      const now = new Date();
      const next = new Date();
      next.setHours(h, m, 0, 0);
      if (next.getTime() <= now.getTime()) {
        next.setDate(next.getDate() + 1);
      }
      const delay = next.getTime() - now.getTime();
      timer = setTimeout(() => {
        fireNotification();
        arm(); // re-arm for next day
      }, delay);
    }
    function fireNotification() {
      try {
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          new Notification("محراب", {
            body: "یادت باشد نمازهای قضای امروز را انجام بدهی. 🕌",
            icon: "/icon.svg",
            tag: "mehrab-reminder",
          });
        }
      } catch {
        // ignore — notifications may be blocked
      }
    }
    arm();
    return () => clearTimeout(timer);
  }, [reminders.enabled, reminders.time, reminders.permission]);
}

/** Request browser notification permission and persist the result. */
export async function requestReminderPermission(): Promise<
  "default" | "granted" | "denied" | "unsupported"
> {
  if (typeof Notification === "undefined") return "unsupported";
  if (Notification.permission === "granted") return "granted";
  if (Notification.permission === "denied") return "denied";
  try {
    const res = await Notification.requestPermission();
    return res as "default" | "granted" | "denied";
  } catch {
    return "denied";
  }
}
