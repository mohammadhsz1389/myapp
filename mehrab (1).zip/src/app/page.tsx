"use client";

import * as React from "react";
import dynamic from "next/dynamic";
import { useStore } from "@/lib/store";
import { BottomNav, type ViewKey } from "@/components/layout/bottom-nav";
import { AppHeader } from "@/components/layout/app-header";
import { useAchievementsSync } from "@/hooks/use-achievements-sync";
import { useReminders } from "@/hooks/use-reminders";
import { jalaaliLong, toFa } from "@/lib/persian";
import { remainingDays } from "@/lib/calculations";

// Views are client-only and lazy to keep initial bundle small.
const OnboardingFlow = dynamic(
  () =>
    import("@/components/views/onboarding-flow").then((m) => m.default),
  { ssr: false },
);
const InitialSetup = dynamic(
  () => import("@/components/views/initial-setup").then((m) => m.default),
  { ssr: false },
);
const HomeView = dynamic(
  () => import("@/components/views/home-view").then((m) => m.default),
  { ssr: false },
);
const QadaView = dynamic(
  () => import("@/components/views/qada-view").then((m) => m.default),
  { ssr: false },
);
const DhikrView = dynamic(
  () => import("@/components/views/dhikr-view").then((m) => m.default),
  { ssr: false },
);
const StatsView = dynamic(
  () => import("@/components/views/stats-view").then((m) => m.default),
  { ssr: false },
);
const SettingsView = dynamic(
  () => import("@/components/views/settings-view").then((m) => m.default),
  { ssr: false },
);

export default function Page() {
  return <AppShell />;
}

function AppShell() {
  const [hydrated, setHydrated] = React.useState(false);
  React.useEffect(() => {
    // wait for zustand-persist to rehydrate from localStorage
    const unsubFinish = useStore.persist.onFinishHydration(() =>
      setHydrated(true),
    );
    if (useStore.persist.hasHydrated()) setHydrated(true);
    return () => unsubFinish();
  }, []);

  if (!hydrated) {
    return <Splash />;
  }

  return <Gate />;
}

function Splash() {
  return (
    <div className="min-h-[100dvh] flex items-center justify-center bg-background">
      <div className="flex flex-col items-center gap-3">
        <div className="size-16 rounded-2xl bg-primary text-primary-foreground flex items-center justify-center font-display text-2xl shadow-sm">
          م
        </div>
        <p className="text-muted-foreground text-sm">محراب</p>
      </div>
    </div>
  );
}

function Gate() {
  const onboarded = useStore((s) => s.onboarded);
  const setupComplete = useStore((s) => s.setupComplete);

  // active global hooks once inside the app
  useAchievementsSync();
  useReminders();

  if (!onboarded) return <OnboardingFlow />;
  if (!setupComplete) return <InitialSetup />;

  return <MainApp />;
}

function MainApp() {
  const [view, setView] = React.useState<ViewKey>("home");
  const s = useStore();

  const subtitle =
    view === "home"
      ? `${jalaaliLong(new Date())} • ${toFa(remainingDays(s))} روز باقی‌مانده`
      : undefined;

  return (
    <div className="min-h-[100dvh] flex flex-col bg-background">
      <AppHeader view={view} subtitle={subtitle} />
      <main className="flex-1">
        {view === "home" && <HomeView />}
        {view === "qada" && <QadaView />}
        {view === "dhikr" && <DhikrView />}
        {view === "stats" && <StatsView />}
        {view === "settings" && <SettingsView />}
      </main>
      <BottomNav current={view} onChange={setView} />
      <div className="h-[60px]" aria-hidden />
    </div>
  );
}
