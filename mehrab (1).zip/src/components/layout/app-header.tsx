"use client";

import * as React from "react";

const VIEW_TITLES: Record<string, string> = {
  home: "محراب",
  qada: "نماز قضا",
  dhikr: "اذکار و اعمال",
  stats: "آمار",
  settings: "تنظیمات",
};

export function AppHeader({
  view,
  subtitle,
}: {
  view: string;
  subtitle?: string;
}) {
  return (
    <header className="sticky top-0 z-30 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
      <div className="mx-auto w-full max-w-md px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="size-9 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-display text-lg shadow-sm">
            م
          </div>
          <div className="leading-tight">
            <h1 className="font-bold text-foreground text-base">
              {VIEW_TITLES[view] ?? "محراب"}
            </h1>
            {subtitle ? (
              <p className="text-[11px] text-muted-foreground">{subtitle}</p>
            ) : null}
          </div>
        </div>
      </div>
    </header>
  );
}
