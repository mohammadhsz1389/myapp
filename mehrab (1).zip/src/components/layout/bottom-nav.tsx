"use client";

import * as React from "react";
import { Home, BookOpenCheck, Sparkles, BarChart3, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

export type ViewKey = "home" | "qada" | "dhikr" | "stats" | "settings";

const NAV_ITEMS: {
  key: ViewKey;
  label: string;
  icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
}[] = [
  { key: "home", label: "خانه", icon: Home },
  { key: "qada", label: "نماز قضا", icon: BookOpenCheck },
  { key: "dhikr", label: "اذکار و اعمال", icon: Sparkles },
  { key: "stats", label: "آمار", icon: BarChart3 },
  { key: "settings", label: "تنظیمات", icon: Settings },
];

export function BottomNav({
  current,
  onChange,
}: {
  current: ViewKey;
  onChange: (v: ViewKey) => void;
}) {
  return (
    <nav
      aria-label="ناوبری اصلی"
      className="fixed bottom-0 inset-x-0 z-40 border-t border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80"
    >
      <div className="mx-auto w-full max-w-md grid grid-cols-5">
        {NAV_ITEMS.map((item) => {
          const active = current === item.key;
          const I = item.icon;
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => onChange(item.key)}
              aria-current={active ? "page" : undefined}
              className={cn(
                "tap-safe relative flex flex-col items-center justify-center gap-1 py-2.5 text-[11px] font-medium transition-colors",
                "min-h-[60px] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/40 rounded-t-lg",
                active
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {active ? (
                <span className="absolute top-0 h-0.5 w-8 rounded-full bg-primary" />
              ) : null}
              <I
                className={cn("size-5 transition-transform", active && "scale-110")}
                strokeWidth={active ? 2.4 : 2}
              />
              <span className={cn(active && "font-bold")}>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
