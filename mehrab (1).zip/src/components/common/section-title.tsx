"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

export function SectionTitle({
  title,
  subtitle,
  action,
  className,
}: {
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={cn("flex items-end justify-between gap-2", className)}>
      <div className="space-y-0.5">
        <h2 className="text-base font-bold text-foreground leading-tight">
          {title}
        </h2>
        {subtitle ? (
          <p className="text-xs text-muted-foreground">{subtitle}</p>
        ) : null}
      </div>
      {action}
    </div>
  );
}
