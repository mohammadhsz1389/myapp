"use client";

import * as React from "react";
import { cn } from "@/lib/utils";

/** Renders numbers in Persian digits without changing the underlying value. */
export function PersianNumber({
  value,
  className,
  separator = true,
}: {
  value: number | string;
  className?: string;
  separator?: boolean;
}) {
  const text = React.useMemo(() => {
    if (typeof value === "string") return value;
    if (!isFinite(value)) return "۰";
    if (separator) {
      return value.toLocaleString("en-US");
    }
    return String(value);
  }, [value, separator]);
  const fa = text.replace(/[0-9]/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[+d]);
  return <span className={cn("tabular-nums", className)}>{fa}</span>;
}
