"use client";

import * as React from "react";
import { LucideIcon, icons } from "lucide-react";
import { cn } from "@/lib/utils";

const iconRegistry = icons as unknown as Record<string, LucideIcon>;

// Renders a lucide icon by its string name. Used for achievement icons.
export function Icon({
  name,
  className,
  strokeWidth = 2,
}: {
  name: string;
  className?: string;
  strokeWidth?: number;
}) {
  const Cmp = iconRegistry[name] ?? iconRegistry["Circle"];
  return <Cmp className={cn(className)} strokeWidth={strokeWidth} />;
}
