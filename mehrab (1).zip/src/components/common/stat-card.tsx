"use client";

import * as React from "react";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

export function StatCard({
  label,
  value,
  unit,
  hint,
  icon,
  accent,
  className,
}: {
  label: string;
  value: React.ReactNode;
  unit?: string;
  hint?: string;
  icon?: React.ReactNode;
  accent?: "default" | "gold" | "primary";
  className?: string;
}) {
  return (
    <Card
      className={cn(
        "p-4 gap-1.5 shadow-none border",
        accent === "gold" && "border-gold/40 bg-gold/5",
        accent === "primary" && "border-primary/30 bg-primary/5",
        className,
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="text-xs text-muted-foreground">{label}</span>
        {icon ? <span className="text-muted-foreground size-4">{icon}</span> : null}
      </div>
      <div className="flex items-baseline gap-1">
        <span className="text-2xl font-bold tabular-nums text-foreground">
          {value}
        </span>
        {unit ? <span className="text-xs text-muted-foreground">{unit}</span> : null}
      </div>
      {hint ? (
        <p className="text-[11px] text-muted-foreground leading-relaxed">{hint}</p>
      ) : null}
    </Card>
  );
}
