"use client";

import * as React from "react";
import { motion, type PanInfo } from "framer-motion";
import {
  Sparkles,
  ListChecks,
  Wrench,
  Rocket,
  Check,
  ChevronLeft,
  ChevronRight,
  type LucideIcon,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { PersianNumber } from "@/components/common/persian-number";
import { useStore } from "@/lib/store";
import { toFa } from "@/lib/persian";

interface Slide {
  icon: LucideIcon;
  title: string;
  content: React.ReactNode;
}

const QADA_BULLETS: string[] = [
  "وارد کردن تعداد واقعی نمازهای قضا",
  "ثبت تک‌تک نمازها",
  "تعیین هدف روزانه",
  "دیدن پیشرفت واقعی",
];

const TOOL_CHIPS: string[] = [
  "آمار و نمودار",
  "تقویم فعالیت",
  "شمارنده ذکر",
  "مسیر شخصی",
  "دستاوردها",
  "تاریخچه",
];

const SLIDES: Slide[] = [
  {
    icon: Sparkles,
    title: "محراب",
    content: (
      <p className="text-center text-base leading-7 text-muted-foreground">
        همراه آرام شما برای جبران نمازهای قضا و رشد معنوی.
      </p>
    ),
  },
  {
    icon: ListChecks,
    title: "پیگیری نماز قضا",
    content: (
      <ul className="w-full space-y-3">
        {QADA_BULLETS.map((t) => (
          <li key={t} className="flex items-start gap-3">
            <span className="mt-0.5 flex size-6 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Check className="size-4" strokeWidth={2.5} />
            </span>
            <span className="text-sm leading-6 text-foreground">{t}</span>
          </li>
        ))}
      </ul>
    ),
  },
  {
    icon: Wrench,
    title: "ابزارهای همراه",
    content: (
      <div className="flex flex-wrap justify-center gap-2">
        {TOOL_CHIPS.map((t) => (
          <span
            key={t}
            className="rounded-full border border-primary/20 bg-primary/5 px-3 py-1.5 text-sm text-primary"
          >
            {t}
          </span>
        ))}
      </div>
    ),
  },
  {
    icon: Rocket,
    title: "آماده‌ای؟",
    content: (
      <p className="text-center text-base leading-7 text-muted-foreground">
        فقط در چند گام کوتاه، پروفایل خود را بساز و سفر جبران نمازهای قضا را آغاز کن.
      </p>
    ),
  },
];

export default function OnboardingFlow() {
  const completeOnboarding = useStore((s) => s.completeOnboarding);
  const [index, setIndex] = React.useState(0);
  const [direction, setDirection] = React.useState(0);

  const total = SLIDES.length;
  const isLast = index === total - 1;

  const go = React.useCallback(
    (next: number) => {
      const clamped = Math.max(0, Math.min(total - 1, next));
      setDirection(clamped > index ? 1 : clamped < index ? -1 : 0);
      setIndex(clamped);
    },
    [index, total],
  );

  const next = React.useCallback(() => {
    if (isLast) {
      completeOnboarding();
      return;
    }
    go(index + 1);
  }, [index, isLast, go, completeOnboarding]);

  const prev = React.useCallback(() => {
    if (index === 0) return;
    go(index - 1);
  }, [index, go]);

  const onDragEnd = React.useCallback(
    (_: unknown, info: PanInfo) => {
      // RTL swipe: finger moving leftward (offset.x < 0) → go to next slide
      //             finger moving rightward (offset.x > 0) → go to previous slide
      if (info.offset.x < -80) {
        next();
      } else if (info.offset.x > 80) {
        prev();
      }
    },
    [next, prev],
  );

  const slide = SLIDES[index];
  const Icon = slide.icon;

  return (
    <div className="flex min-h-[100dvh] flex-col bg-background">
      {/* Top bar: slide counter + skip */}
      <div className="flex items-center justify-between px-4 pt-4">
        <span className="text-xs tabular-nums text-muted-foreground">
          <PersianNumber value={index + 1} separator={false} /> از{" "}
          <PersianNumber value={total} separator={false} />
        </span>
        <Button
          variant="ghost"
          size="sm"
          onClick={completeOnboarding}
          className="text-muted-foreground hover:text-foreground"
        >
          رد کردن
        </Button>
      </div>

      {/* Slide content */}
      <div className="flex flex-1 flex-col items-center justify-center px-6 py-8">
        <motion.div
          key={index}
          initial={{ opacity: 0, x: direction * -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          drag="x"
          dragConstraints={{ left: 0, right: 0 }}
          dragElastic={0.18}
          onDragEnd={onDragEnd}
          className="flex w-full max-w-sm flex-col items-center gap-6"
        >
          <div className="flex size-24 items-center justify-center rounded-full bg-primary/10 text-primary">
            <Icon className="size-14" strokeWidth={1.5} />
          </div>
          <h1 className="font-display text-center text-2xl text-foreground">
            {slide.title}
          </h1>
          <div className="flex w-full flex-col items-center">{slide.content}</div>
        </motion.div>
      </div>

      {/* Bottom: dots + nav buttons */}
      <div className="space-y-5 px-6 pb-8 pt-2">
        {/* Dots */}
        <div className="flex items-center justify-center gap-2">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              type="button"
              aria-label={`رفتن به اسلاید ${toFa(i + 1)}`}
              onClick={() => go(i)}
              className={`h-2 rounded-full transition-all tap-safe ${
                i === index
                  ? "w-6 bg-primary"
                  : "w-2 bg-muted-foreground/30 hover:bg-muted-foreground/50"
              }`}
            />
          ))}
        </div>

        {/* Nav buttons */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={prev}
            disabled={index === 0}
            className="flex-1"
            size="lg"
          >
            <ChevronRight className="size-4" />
            قبلی
          </Button>
          {isLast ? (
            <Button
              onClick={completeOnboarding}
              className="flex-1"
              size="lg"
            >
              <Sparkles className="size-4" />
              شروع کنیم
            </Button>
          ) : (
            <Button onClick={next} className="flex-1" size="lg">
              بعدی
              <ChevronLeft className="size-4" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
