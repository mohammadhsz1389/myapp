"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Check,
  BookOpenCheck,
  Sparkles,
  Trophy,
  Trash2,
  Undo2,
} from "lucide-react";

import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SectionTitle } from "@/components/common/section-title";
import { EmptyState } from "@/components/common/empty-state";
import { PersianNumber } from "@/components/common/persian-number";
import { ConfirmDialog } from "@/components/common/confirm-dialog";

import { useStore } from "@/lib/store";
import {
  totalQadaDays,
  completedDayCount,
  remainingDays,
  overallProgress,
  activeDayIndex,
  dayCompletionRatio,
  historyEntries,
} from "@/lib/calculations";
import { PRAYERS } from "@/lib/config";
import { faDateTime } from "@/lib/persian";
import { cn } from "@/lib/utils";
import type { PrayerKey } from "@/lib/types";

export default function QadaView() {
  const s = useStore();

  // Guard — should not happen (qada is gated behind setup)
  if (!s.profile) return null;

  const total = totalQadaDays(s);
  const completed = completedDayCount(s);
  const remaining = remainingDays(s);
  const progress = overallProgress(s);
  const activeIdx = activeDayIndex(s);
  const isComplete = activeIdx === -1;
  const history = historyEntries(s).slice(0, 8);
  const percentRound = Math.round(progress);
  const progressLabel =
    progress > 0 && percentRound === 0 ? "کمتر از ۱" : null;

  // Build the recent-days range
  let startIdx: number;
  let endIdx: number;
  if (isComplete) {
    startIdx = Math.max(0, total - 10);
    endIdx = total;
  } else {
    startIdx = Math.max(0, activeIdx - 10);
    endIdx = Math.min(total, activeIdx + 2);
  }
  const recentIndices: number[] = [];
  for (let i = endIdx - 1; i >= startIdx; i--) recentIndices.push(i);

  return (
    <main
      dir="rtl"
      className="mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24"
    >
      {/* ── 1. Summary header card ── */}
      <Card className="p-5 gap-4">
        <SectionTitle title="نماز قضا" subtitle="خلاصه‌ای از مسیر قضای شما" />
        <div className="grid grid-cols-3 gap-2">
          <SummaryCell label="تعداد کل" value={total} />
          <SummaryCell
            label="انجام‌شده"
            value={completed}
            accent="primary"
          />
          <SummaryCell
            label="باقی‌مانده"
            value={remaining}
            accent="gold"
          />
        </div>
        <div className="space-y-1.5">
          <Progress value={progress} className="h-2.5" />
          <div className="flex items-center justify-between text-[11px] text-muted-foreground">
            <span>
              {progressLabel ?? <PersianNumber value={percentRound} />}٪ پیشرفت
            </span>
            <span>
              <PersianNumber value={completed} /> از{" "}
              <PersianNumber value={total} /> روز
            </span>
          </div>
        </div>
      </Card>

      {/* ── 2. Active day card (big) ── */}
      {isComplete ? (
        <Card className="p-6 gap-3 border-gold/30 bg-gold/5">
          <EmptyState
            icon="Trophy"
            title="مسیر قضا کامل شد!"
            description="تمام نمازهای قضای شما به پایان رسید."
            className="py-6"
          />
        </Card>
      ) : (
        <ActiveDayCard activeIdx={activeIdx} />
      )}

      {/* ── 3. Recent days list ── */}
      {!isComplete && recentIndices.length > 0 ? (
        <Card className="p-5 gap-3">
          <SectionTitle
            title="روزهای اخیر قضا"
            subtitle="برای اصلاح یا برگرداندن، روی هر نماز بزن"
          />
          <div className="space-y-2 max-h-96 overflow-y-auto slim-scroll pr-1">
            {recentIndices.map((idx) => (
              <RecentDayRow key={idx} dayIdx={idx} isActive={idx === activeIdx} />
            ))}
          </div>
        </Card>
      ) : null}

      {/* ── 4. History preview ── */}
      <Card className="p-5 gap-3">
        <SectionTitle
          title="تاریخچه اخیر"
          subtitle="آخرین فعالیت‌های ثبت‌شده"
        />
        {history.length === 0 ? (
          <EmptyState
            icon="History"
            title="هنوز سابقه‌ای ثبت نشده است."
            description="با اولین نماز قضا یا ذکر، اینجا نمایش داده می‌شود."
            className="py-6"
          />
        ) : (
          <ul className="space-y-2 max-h-96 overflow-y-auto slim-scroll pr-1">
            {history.map((entry) => {
              const isPrayer = entry.kind === "prayer";
              const Icon = isPrayer ? BookOpenCheck : Sparkles;
              return (
                <li
                  key={entry.id}
                  className="flex items-center gap-3 rounded-lg border border-border bg-background px-3 py-2.5"
                >
                  <div
                    className={cn(
                      "size-9 rounded-xl flex items-center justify-center shrink-0",
                      isPrayer
                        ? "bg-primary/10 text-primary"
                        : "bg-gold/15 text-gold",
                    )}
                  >
                    <Icon className="size-4.5" />
                  </div>
                  <div className="flex-1 min-w-0 space-y-0.5">
                    <p className="text-sm font-medium text-foreground truncate">
                      {entry.label}
                    </p>
                    <p className="text-[11px] text-muted-foreground tabular-nums">
                      {faDateTime(entry.ts)}
                    </p>
                  </div>
                  {isPrayer && entry.dayIndex != null && entry.prayer ? (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() =>
                        s.setPrayer(entry.dayIndex!, entry.prayer!, false)
                      }
                      className="text-destructive hover:text-destructive hover:bg-destructive/10 h-8 gap-1.5 px-2 text-[11px]"
                      aria-label="برگشت این نماز"
                    >
                      <Undo2 className="size-3.5" />
                      برگشت
                    </Button>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </Card>
    </main>
  );
}

// ───────────────────────── Summary cell ─────────────────────────
function SummaryCell({
  label,
  value,
  accent,
}: {
  label: string;
  value: number;
  accent?: "primary" | "gold";
}) {
  return (
    <div
      className={cn(
        "rounded-lg border p-2.5 text-center space-y-1",
        accent === "primary" && "border-primary/30 bg-primary/5",
        accent === "gold" && "border-gold/40 bg-gold/5",
        !accent && "border-border bg-muted/30",
      )}
    >
      <p className="text-[10px] text-muted-foreground">{label}</p>
      <p
        className={cn(
          "text-2xl font-bold tabular-nums leading-none",
          accent === "primary" && "text-primary",
          accent === "gold" && "text-gold",
          !accent && "text-foreground",
        )}
      >
        <PersianNumber value={value} />
      </p>
    </div>
  );
}

// ───────────────────────── Active day card ─────────────────────────
function ActiveDayCard({ activeIdx }: { activeIdx: number }) {
  const s = useStore();
  const ratio = dayCompletionRatio(activeIdx, s);
  const isFull = ratio === 5;
  const [confirmOpen, setConfirmOpen] = React.useState(false);

  return (
    <Card className="p-5 gap-4 border-primary/20">
      <div className="flex items-start justify-between gap-2">
        <div className="space-y-0.5">
          <h3 className="font-bold text-foreground">نماز قضای امروز</h3>
          <p className="text-xs text-muted-foreground">
            روز قضا <span className="font-medium">#
              <PersianNumber value={activeIdx + 1} />
            </span>
          </p>
        </div>
        <Badge
          variant={isFull ? "default" : "secondary"}
          className={cn(
            "text-[11px]",
            isFull && "bg-gold text-gold-foreground border-gold",
          )}
        >
          <PersianNumber value={ratio} /> از ۵
        </Badge>
      </div>

      {/* Vertical large prayer rows */}
      <div className="space-y-2">
        {PRAYERS.map((p) => {
          const day = s.qadaDays[activeIdx];
          const done = !!day?.prayers?.[p.key as PrayerKey]?.done;
          return (
            <PrayerRow
              key={p.key}
              name={p.name}
              shortName={p.shortName}
              rakat={p.rakat}
              done={done}
              onClick={() => s.togglePrayer(activeIdx, p.key)}
            />
          );
        })}
      </div>

      {/* completion status / hint */}
      {isFull ? (
        <div className="flex items-center gap-2 rounded-lg bg-gold/10 px-3 py-2 text-gold">
          <Trophy className="size-4" />
          <p className="text-sm font-medium">این روز کامل شد</p>
        </div>
      ) : (
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          با تکمیل این روز، روز بعدی به‌صورت خودکار فعال می‌شود.
        </p>
      )}

      {/* Clear day */}
      <div className="pt-1 border-t border-border">
        <ConfirmDialog
          open={confirmOpen}
          onOpenChange={setConfirmOpen}
          title="پاک کردن این روز قضا"
          description="آیا مطمئن هستید؟ تمام نمازهای این روز قضا پاک خواهد شد."
          confirmText="پاک کن"
          cancelText="انصراف"
          destructive
          onConfirm={() => {
            s.clearDay(activeIdx);
            setConfirmOpen(false);
          }}
          trigger={
            <Button
              variant="ghost"
              size="sm"
              className="text-destructive hover:text-destructive hover:bg-destructive/10 w-full h-9 gap-1.5 text-xs"
            >
              <Trash2 className="size-3.5" />
              پاک کردن این روز
            </Button>
          }
        />
      </div>
    </Card>
  );
}

// ───────────────────────── Prayer row (large, vertical list) ─────────────────────────
function PrayerRow({
  name,
  shortName,
  rakat,
  done,
  onClick,
}: {
  name: string;
  shortName: string;
  rakat: number;
  done: boolean;
  onClick: () => void;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.1 }}
      aria-pressed={done}
      className={cn(
        "tap-safe w-full min-h-[3.5rem] flex items-center justify-between gap-3 rounded-xl border px-3.5 py-3 transition-colors text-right",
        done
          ? "border-primary bg-primary/10 text-foreground"
          : "border-border bg-background text-foreground hover:bg-accent/60",
      )}
    >
      <div className="flex flex-col items-start gap-0.5 min-w-0">
        <span className="font-semibold text-sm leading-tight">{name}</span>
        <span className="text-[11px] text-muted-foreground tabular-nums">
          <PersianNumber value={rakat} /> رکعت · {shortName}
        </span>
      </div>
      <span
        className={cn(
          "size-9 rounded-full flex items-center justify-center shrink-0 transition-colors border-2",
          done
            ? "bg-primary border-primary text-primary-foreground shadow-sm"
            : "border-border text-transparent",
        )}
        aria-hidden
      >
        <Check className="size-5" strokeWidth={3} />
      </span>
    </motion.button>
  );
}

// ───────────────────────── Recent day row (compact) ─────────────────────────
function RecentDayRow({
  dayIdx,
  isActive,
}: {
  dayIdx: number;
  isActive: boolean;
}) {
  const s = useStore();
  const day = s.qadaDays[dayIdx];
  const ratio = dayCompletionRatio(dayIdx, s);
  const isComplete = ratio === 5;

  return (
    <div
      className={cn(
        "rounded-xl border p-3 space-y-2 transition-colors",
        isActive
          ? "border-primary/40 bg-primary/5"
          : isComplete
            ? "border-gold/30 bg-gold/5"
            : "border-border bg-background",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <span className="text-[11px] text-muted-foreground shrink-0">
            روز قضا
          </span>
          <span className="text-sm font-semibold tabular-nums">
            #<PersianNumber value={dayIdx + 1} />
          </span>
          {isActive ? (
            <Badge variant="secondary" className="text-[10px] h-5">
              امروز
            </Badge>
          ) : null}
        </div>
        <div className="flex items-center gap-1.5">
          {isComplete ? (
            <span className="inline-flex items-center justify-center size-5 rounded-full bg-gold/20 text-gold">
              <Check className="size-3" strokeWidth={3} />
            </span>
          ) : (
            <span className="text-[10px] text-muted-foreground tabular-nums">
              <PersianNumber value={ratio} />/۵
            </span>
          )}
        </div>
      </div>

      {/* mini toggles */}
      <div className="grid grid-cols-5 gap-1.5">
        {PRAYERS.map((p) => {
          const done = !!day?.prayers?.[p.key as PrayerKey]?.done;
          return (
            <button
              key={p.key}
              type="button"
              onClick={() => s.togglePrayer(dayIdx, p.key)}
              aria-pressed={done}
              aria-label={`${p.name} - ${done ? "انجام‌شده" : "انجام‌نشده"}`}
              title={p.name}
              className={cn(
                "tap-safe flex flex-col items-center gap-1 rounded-lg py-1.5 min-h-[2.75rem] text-[10px] transition-colors border",
                done
                  ? "bg-primary/15 text-primary border-primary/30"
                  : "bg-background text-muted-foreground border-border hover:bg-accent/60",
              )}
            >
              <span
                className={cn(
                  "size-2 rounded-full transition-colors",
                  done ? "bg-primary" : "bg-muted-foreground/30",
                )}
              />
              <span className="leading-none">{p.shortName}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
