"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Flame,
  Check,
  Trophy,
  Sparkles,
  Target,
  BookOpenCheck,
  CalendarDays,
  Activity,
  Award,
} from "lucide-react";

import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { StatCard } from "@/components/common/stat-card";
import { SectionTitle } from "@/components/common/section-title";
import { EmptyState } from "@/components/common/empty-state";
import { PersianNumber } from "@/components/common/persian-number";
import { Icon } from "@/components/common/icon";

import { useStore } from "@/lib/store";
import {
  remainingDays,
  completedDayCount,
  overallProgress,
  activeDayIndex,
  dayCompletionRatio,
  levelInfo,
  totalXp,
  totalRakat,
  totalDhikrCount,
  activeDaysCount,
  bestDay,
  dailyGoalTarget,
  prayersToday,
  currentStreak,
  personalPath,
  isAchievementEverUnlocked,
  totalQadaDays,
} from "@/lib/calculations";
import {
  ACHIEVEMENTS,
  PRAYERS,
} from "@/lib/config";
import { cn } from "@/lib/utils";
import type { PrayerKey } from "@/lib/types";

export default function HomeView() {
  const s = useStore();

  // Guard — should not happen (home is gated behind setup), but stay safe.
  if (!s.profile) return null;

  const total = totalQadaDays(s);
  const remaining = remainingDays(s);
  const completed = completedDayCount(s);
  const progress = overallProgress(s);
  const activeIdx = activeDayIndex(s);
  const level = levelInfo(s);
  const xp = totalXp(s);
  const rakat = totalRakat(s);
  const dhikrTotal = totalDhikrCount(s);
  const activeDays = activeDaysCount(s);
  const best = bestDay(s);
  const goalTarget = dailyGoalTarget(s);
  const todayCount = prayersToday(s);
  const streak = currentStreak(s);
  const path = personalPath(s);
  const isComplete = activeIdx === -1;
  const percentRound = Math.round(progress);
  // Show "کمتر از ۱" when real progress exists but rounds to 0 (e.g. 1/300).
  const progressLabel =
    progress > 0 && percentRound === 0 ? "کمتر از ۱" : null;

  return (
    <main
      dir="rtl"
      className="mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24"
    >
      {/* ── 1. Hero progress card ── */}
      <Card className="p-5 gap-4 border-primary/15 bg-gradient-to-b from-primary/5 to-transparent">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">پیشرفت کلی مسیر قضا</p>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold tabular-nums text-foreground">
                {progressLabel ?? <PersianNumber value={percentRound} />}
              </span>
              <span className="text-sm text-muted-foreground">٪</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1 text-left">
            <div className="flex items-baseline gap-1">
              <span className="text-2xl font-bold tabular-nums text-gold">
                <PersianNumber value={remaining} />
              </span>
              <span className="text-xs text-muted-foreground">روز باقی‌مانده</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className="text-base font-semibold tabular-nums text-foreground">
                <PersianNumber value={completed} />
              </span>
              <span className="text-[11px] text-muted-foreground">
                از <PersianNumber value={total} /> روز انجام‌شده
              </span>
            </div>
          </div>
        </div>

        <Progress value={progress} className="h-2.5" />

        {progress >= 100 ? (
          <div className="flex items-center gap-2 rounded-lg bg-gold/10 px-3 py-2 text-gold">
            <Trophy className="size-4" />
            <p className="text-sm font-medium leading-relaxed">
              الحمدلله! مسیر قضا به پایان رسید.
            </p>
          </div>
        ) : (
          <p className="text-xs text-muted-foreground leading-relaxed">
            با هر روز کامل، یک قدم به پایان نزدیک‌تر می‌شوی.
          </p>
        )}
      </Card>

      {/* ── 2. Today's Qada (active day) ── */}
      {isComplete ? (
        <Card className="p-5 gap-3 border-gold/30 bg-gold/5">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-full bg-gold/20 flex items-center justify-center text-gold">
              <Trophy className="size-5" />
            </div>
            <div className="space-y-0.5">
              <p className="font-bold text-foreground">نماز قضای امروز</p>
              <p className="text-xs text-muted-foreground">
                تمام نمازهای قضای شما کامل شد.
              </p>
            </div>
          </div>
        </Card>
      ) : (
        <Card className="p-5 gap-4">
          <div className="flex items-start justify-between gap-2">
            <div className="space-y-0.5">
              <h3 className="font-bold text-foreground">نماز قضای امروز</h3>
              <p className="text-xs text-muted-foreground">
                روز قضا <span className="font-medium">#
                  <PersianNumber value={activeIdx + 1} />
                </span>
              </p>
            </div>
            <Badge variant="secondary" className="text-[11px]">
              <PersianNumber value={dayCompletionRatio(activeIdx, s)} /> از ۵
            </Badge>
          </div>

          <div className="grid grid-cols-5 gap-2">
            {PRAYERS.map((p) => {
              const day = s.qadaDays[activeIdx];
              const done = !!day?.prayers?.[p.key as PrayerKey]?.done;
              return (
                <PrayerChip
                  key={p.key}
                  label={p.shortName}
                  done={done}
                  onClick={() => s.togglePrayer(activeIdx, p.key)}
                />
              );
            })}
          </div>

          <p className="text-[11px] text-muted-foreground leading-relaxed">
            برای مدیریت کامل، به بخش «نماز قضا» برو.
          </p>
        </Card>
      )}

      {/* ── 3. Today summary row ── */}
      <div className="grid grid-cols-3 gap-3">
        <StatCard
          label="هدف امروز"
          value={<PersianNumber value={goalTarget} />}
          unit="نماز"
          icon={<Target className="size-4" />}
        />
        <StatCard
          label="نمازهای امروز"
          value={<PersianNumber value={todayCount} />}
          unit="نماز"
          icon={<BookOpenCheck className="size-4" />}
          accent={todayCount >= goalTarget ? "primary" : "default"}
        />
        <StatCard
          label="استریک"
          value={<PersianNumber value={streak} />}
          unit="روز"
          icon={<Flame className="size-4" />}
          accent={streak > 0 ? "gold" : "default"}
        />
      </div>

      {/* ── 4. Level & XP card ── */}
      <Card className="p-5 gap-3 border-gold/30 bg-gold/5">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="size-10 rounded-xl bg-gold/15 text-gold flex items-center justify-center">
              <Award className="size-5" />
            </div>
            <div className="space-y-0.5">
              <p className="text-xs text-muted-foreground">سطح فعلی</p>
              <p className="font-bold text-foreground leading-none">
                سطح <PersianNumber value={level.level} /> · {level.name}
              </p>
            </div>
          </div>
          <div className="text-left space-y-0.5">
            <p className="text-xs text-muted-foreground">امتیاز (XP)</p>
            <p className="text-xl font-bold tabular-nums text-gold">
              <PersianNumber value={xp} />
            </p>
          </div>
        </div>
        <div className="space-y-1.5">
          <Progress
            value={level.pct}
            className="h-2 [&>div]:bg-gold"
          />
          <div className="flex items-center justify-between text-[11px] text-muted-foreground">
            <span>
              <PersianNumber value={Math.round(level.pct)} />٪ مسیر سطح بعد
            </span>
            <span>
              <PersianNumber value={level.toNext} /> امتیاز تا سطح بعد
            </span>
          </div>
        </div>
      </Card>

      {/* ── 5. مسیر من mini ── */}
      <Card className="p-5 gap-3">
        <SectionTitle
          title="مسیر من"
          subtitle="نگاهی فشرده به نقاط عطف سفر قضا"
        />
        {path.length === 0 ? (
          <p className="text-xs text-muted-foreground">مسیری تعریف نشده است.</p>
        ) : (
          <>
            <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-1">
              {path.map((m, i) => {
                const cls = m.isCurrent
                  ? "bg-emerald-500 text-white border-emerald-500 scale-110"
                  : m.isReached
                    ? "bg-gold/20 text-gold border-gold/50"
                    : "bg-muted text-muted-foreground border-border";
                return (
                  <React.Fragment key={i}>
                    <div className="flex flex-col items-center gap-1.5 shrink-0">
                      <span
                        className={cn(
                          "size-3.5 rounded-full border-2 transition-all",
                          cls,
                        )}
                      />
                      <span
                        className={cn(
                          "text-[10px] whitespace-nowrap",
                          m.isCurrent
                            ? "font-bold text-foreground"
                            : "text-muted-foreground",
                        )}
                      >
                        {m.label}
                      </span>
                    </div>
                    {i < path.length - 1 ? (
                      <div
                        className={cn(
                          "h-0.5 w-6 rounded-full shrink-0",
                          m.isReached ? "bg-gold/40" : "bg-border",
                        )}
                      />
                    ) : null}
                  </React.Fragment>
                );
              })}
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              مسیر کامل در بخش «آمار».
            </p>
          </>
        )}
      </Card>

      {/* ─ـ 6. Quick stats (2-col grid) ── */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          label="کل رکعات"
          value={<PersianNumber value={rakat} />}
          unit="رکعت"
          icon={<Activity className="size-4" />}
        />
        <StatCard
          label="کل اذکار"
          value={<PersianNumber value={dhikrTotal} />}
          unit="مرتبه"
          icon={<Sparkles className="size-4" />}
        />
        <StatCard
          label="روزهای فعال"
          value={<PersianNumber value={activeDays} />}
          unit="روز"
          icon={<CalendarDays className="size-4" />}
        />
        <StatCard
          label="بهترین روز"
          value={
            best ? (
              <PersianNumber value={best.prayers} />
            ) : (
              <span className="text-muted-foreground">—</span>
            )
          }
          unit={best ? "نماز" : undefined}
          icon={<Trophy className="size-4" />}
        />
      </div>

      {/* ── 7. Recent achievements ── */}
      <Card className="p-5 gap-3">
        <SectionTitle
          title="دستاوردهای اخیر"
          subtitle="نشان‌هایی که تاکنون باز کرده‌ای"
        />
        {ACHIEVEMENTS.filter((a) => isAchievementEverUnlocked(s, a.id)).length ===
        0 ? (
          <EmptyState
            icon="Trophy"
            title="هنوز دستاوردی باز نشده است."
            description="با اولین نماز قضا یا ذکر، اولین دستاورد باز می‌شود."
            className="py-6"
          />
        ) : (
          <div className="flex items-center gap-3 overflow-x-auto no-scrollbar py-1">
            {ACHIEVEMENTS.filter((a) =>
              isAchievementEverUnlocked(s, a.id),
            ).map((a) => (
              <div
                key={a.id}
                className="flex flex-col items-center gap-2 shrink-0 w-20"
                title={a.description}
              >
                <div className="size-12 rounded-2xl bg-gold/15 text-gold flex items-center justify-center border border-gold/30">
                  <Icon name={a.icon} className="size-6" />
                </div>
                <span className="text-[10px] text-center font-medium leading-tight text-foreground">
                  {a.title}
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* sr-only landmark for screen readers */}
      <span className="sr-only">صفحه اصلی محراب</span>
    </main>
  );
}

// ── Local helper: compact prayer toggle chip ──
function PrayerChip({
  label,
  done,
  onClick,
}: {
  label: string;
  done: boolean;
  onClick: () => void;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileTap={{ scale: 0.92 }}
      transition={{ duration: 0.12 }}
      aria-pressed={done}
      className={cn(
        "tap-safe flex flex-col items-center justify-center gap-1 rounded-xl py-2.5 min-h-[3.25rem] text-xs font-medium transition-colors border",
        done
          ? "bg-primary text-primary-foreground border-primary shadow-sm"
          : "bg-background text-muted-foreground border-border hover:bg-accent",
      )}
    >
      {done ? (
        <Check className="size-3.5" strokeWidth={2.5} />
      ) : (
        <span className="size-3.5 rounded-full border border-current opacity-50" />
      )}
      <span>{label}</span>
    </motion.button>
  );
}
