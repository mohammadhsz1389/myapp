"use client";

import * as React from "react";
import { useTheme } from "next-themes";
import { toast } from "sonner";
import {
  Bell,
  BellRing,
  Calendar,
  Check,
  Info,
  Lock,
  Minus,
  Pencil,
  Plus,
  RotateCcw,
  ShieldAlert,
  ShieldCheck,
  Trash2,
} from "lucide-react";

import { useStore } from "@/lib/store";
import {
  ACHIEVEMENTS,
  APP_VERSION,
  DAILY_GOAL_OPTIONS,
  MARJA_OPTIONS,
} from "@/lib/config";
import {
  PERSIAN_MONTHS,
  isJalaaliLeap,
  isoDate,
  jalaaliLong,
  jalaaliToDate,
  parseFaInt,
  toFa,
  toJalaali,
} from "@/lib/persian";
import { isAchievementEverUnlocked } from "@/lib/calculations";
import { requestReminderPermission } from "@/hooks/use-reminders";
import { cn } from "@/lib/utils";

import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ConfirmDialog } from "@/components/common/confirm-dialog";
import { SectionTitle } from "@/components/common/section-title";
import { Icon } from "@/components/common/icon";
import { PersianNumber } from "@/components/common/persian-number";

// ───────────────────────── helpers ─────────────────────────

function daysInJalaaliMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  return isJalaaliLeap(jy) ? 30 : 29;
}

// ───────────────────────── section card ─────────────────────────

function SettingsCard({
  title,
  subtitle,
  icon,
  children,
}: {
  title: string;
  subtitle?: string;
  icon?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <Card className="shadow-none">
      <CardContent className="p-5 space-y-4">
        <div className="flex items-center gap-2.5">
          {icon ? (
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              {icon}
            </span>
          ) : null}
          <SectionTitle title={title} subtitle={subtitle} className="flex-1" />
        </div>
        {children}
      </CardContent>
    </Card>
  );
}

// ───────────────────────── main view ─────────────────────────

export default function SettingsView() {
  const state = useStore();
  const profile = state.profile;

  const { theme: appliedTheme, setTheme } = useTheme();
  const [mounted, setMounted] = React.useState(false);
  React.useEffect(() => setMounted(true), []);

  // one-time sync: store is source of truth → apply to next-themes
  React.useEffect(() => {
    if (!mounted || !profile) return;
    const stored = state.settings.theme;
    if (stored && stored !== appliedTheme) {
      setTheme(stored);
    }
  }, [mounted]);

  // ── Section 2: total qada days input (controlled, Persian-aware) ──
  const [qadaInput, setQadaInput] = React.useState("");
  React.useEffect(() => {
    if (profile) setQadaInput(toFa(profile.totalQadaDays));
  }, [profile?.totalQadaDays]);

  // bind store actions to avoid hook re-creation churn
  const store_updateProfile = state.updateProfile;
  const store_updateSettings = state.updateSettings;
  const store_setReminder = state.setReminder;
  const store_resetAll = state.resetAll;
  const store_replayOnboarding = state.replayOnboarding;

  const commitTotal = React.useCallback(
    (raw: string | number) => {
      if (!profile) return;
      const parsed =
        typeof raw === "number"
          ? raw
          : parseFaInt(typeof raw === "string" ? raw : "");
      if (!isFinite(parsed) || parsed < 1) {
        toast.error("مقدار نامعتبر است. حداقل ۱ روز وارد کنید.");
        setQadaInput(toFa(profile.totalQadaDays));
        return;
      }
      if (parsed === profile.totalQadaDays) {
        setQadaInput(toFa(profile.totalQadaDays));
        return;
      }
      store_updateProfile({ totalQadaDays: parsed });
      toast.success("تعداد کل نمازهای قضا به‌روزرسانی شد.");
    },
    [profile, store_updateProfile],
  );

  // ── Section 4: start date dialog ──
  const [dateDialogOpen, setDateDialogOpen] = React.useState(false);
  const [pickerYear, setPickerYear] = React.useState<number>(0);
  const [pickerMonth, setPickerMonth] = React.useState<number>(0);
  const [pickerDay, setPickerDay] = React.useState<number>(0);

  React.useEffect(() => {
    if (dateDialogOpen && profile) {
      const j = toJalaali(new Date(profile.startDate));
      setPickerYear(j.jy);
      setPickerMonth(j.jm);
      setPickerDay(j.jd);
    }
  }, [dateDialogOpen, profile?.startDate]);

  // clamp day if month/year changes
  React.useEffect(() => {
    if (!dateDialogOpen) return;
    const max = daysInJalaaliMonth(pickerYear, pickerMonth);
    if (pickerDay > max) setPickerDay(max);
  }, [pickerYear, pickerMonth, pickerDay, dateDialogOpen]);

  // ── Section 8: confirm dialogs ──
  const [replayOpen, setReplayOpen] = React.useState(false);
  const [resetOpen, setResetOpen] = React.useState(false);

  // ───────────────────────── render guards ─────────────────────────
  if (!profile) {
    return (
      <div className="mx-auto w-full max-w-md px-4 py-4 pb-24">
        <Card className="shadow-none">
          <CardContent className="p-5 text-sm text-muted-foreground">
            هنوز پروفایلی ساخته نشده است. ابتدا راه‌اندازی اولیه را تکمیل کنید.
          </CardContent>
        </Card>
      </div>
    );
  }

  const todayJ = toJalaali(new Date());
  const yearOptions: number[] = [];
  for (let y = todayJ.jy - 30; y <= todayJ.jy + 1; y++) yearOptions.push(y);

  const daysCount = daysInJalaaliMonth(pickerYear, pickerMonth);
  const dayOptions: number[] = [];
  for (let d = 1; d <= daysCount; d++) dayOptions.push(d);

  const reminders = state.settings.reminders;

  return (
    <div className="mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24">
      {/* ─────────────── 1. هدف روزانه ─────────────── */}
      <SettingsCard
        title="هدف روزانه"
        subtitle="تعداد روزهای قضایی که می‌خواهی هر روز بگذرانی."
        icon={<Calendar className="size-4" />}
      >
        <RadioGroup
          value={String(profile.dailyGoal)}
          onValueChange={(v) => {
            const n = Number(v);
            if (!isFinite(n) || n < 1) return;
            store_updateProfile({ dailyGoal: n });
            toast.success("هدف روزانه به‌روزرسانی شد.");
          }}
          className="gap-2"
        >
          {DAILY_GOAL_OPTIONS.map((opt) => {
            const id = `goal-${opt.value}`;
            return (
              <Label
                key={opt.value}
                htmlFor={id}
                className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card p-3.5 cursor-pointer tap-safe transition-colors hover:bg-accent/40 has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5"
              >
                <span className="text-sm font-medium leading-snug">
                  {opt.label}
                </span>
                <RadioGroupItem id={id} value={String(opt.value)} />
              </Label>
            );
          })}
        </RadioGroup>
      </SettingsCard>

      {/* ─────────────── 2. تعداد کل نمازهای قضا ─────────────── */}
      <SettingsCard
        title="تعداد کل نمازهای قضا"
        subtitle="مجموع روزهایی که باید قضایت را انجام دهی."
        icon={<RotateCcw className="size-4" />}
      >
        <div className="flex items-center gap-2">
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-label="کاهش یک روز"
            className="size-11 shrink-0 rounded-lg"
            onClick={() => commitTotal(profile.totalQadaDays - 1)}
          >
            <Minus className="size-4" />
          </Button>
          <Input
            value={qadaInput}
            inputMode="numeric"
            dir="ltr"
            onChange={(e) => setQadaInput(e.target.value)}
            onBlur={(e) => commitTotal(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                (e.target as HTMLInputElement).blur();
              }
            }}
            className="h-11 flex-1 text-center text-base font-bold tabular-nums"
            aria-label="تعداد کل روزهای قضا"
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            aria-label="افزایش یک روز"
            className="size-11 shrink-0 rounded-lg"
            onClick={() => commitTotal(profile.totalQadaDays + 1)}
          >
            <Plus className="size-4" />
          </Button>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">
          اگر این مقدار را کم کنی، روزهای فراتر از مقدار جدید حذف خواهند شد.
        </p>
      </SettingsCard>

      {/* ─────────────── 3. مرجع تقلید ─────────────── */}
      <SettingsCard
        title="مرجع تقلید"
        subtitle="صرفاً یک یادآور شخصی — بدون ادعای فقهی."
        icon={<Info className="size-4" />}
      >
        <Select
          value={profile.marja}
          onValueChange={(v) => {
            store_updateProfile({ marja: v });
            toast.success("مرجع تقلید به‌روزرسانی شد.");
          }}
        >
          <SelectTrigger className="h-11 w-full" aria-label="انتخاب مرجع تقلید">
            <SelectValue placeholder="انتخاب مرجع" />
          </SelectTrigger>
          <SelectContent>
            {MARJA_OPTIONS.map((m) => (
              <SelectItem key={m} value={m}>
                {m}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <p className="text-xs text-muted-foreground leading-relaxed">
          این فقط یک مرجع شخصی است؛ اپلیکیشن در مورد احکام فقهی ادعای خاصی
          ندارد و در موارد تخصصی به مرجع تقلید خود مراجعه کنید.
        </p>
      </SettingsCard>

      {/* ─────────────── 4. تاریخ شروع ─────────────── */}
      <SettingsCard
        title="تاریخ شروع"
        subtitle="تاریخ آغاز مسیر قضای تو."
        icon={<Calendar className="size-4" />}
      >
        <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card p-3.5">
          <div className="space-y-0.5">
            <p className="text-xs text-muted-foreground">تاریخ فعلی</p>
            <p className="text-sm font-bold">
              {jalaaliLong(new Date(profile.startDate))}
            </p>
          </div>
          <Button
            variant="outline"
            size="sm"
            className="h-9 gap-1.5"
            onClick={() => setDateDialogOpen(true)}
          >
            <Pencil className="size-3.5" />
            ویرایش
          </Button>
        </div>

        <Dialog open={dateDialogOpen} onOpenChange={setDateDialogOpen}>
          <DialogContent className="max-w-sm">
            <DialogHeader>
              <DialogTitle>ویرایش تاریخ شروع</DialogTitle>
              <DialogDescription>
                تاریخ شروع را با تقویم جلالی انتخاب کن.
              </DialogDescription>
            </DialogHeader>

            <div className="grid grid-cols-3 gap-2">
              {/* سال */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">سال</Label>
                <Select
                  value={String(pickerYear)}
                  onValueChange={(v) => setPickerYear(Number(v))}
                >
                  <SelectTrigger className="h-10 w-full" aria-label="سال">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {yearOptions
                      .slice()
                      .reverse()
                      .map((y) => (
                        <SelectItem key={y} value={String(y)}>
                          {toFa(y)}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
              {/* ماه */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">ماه</Label>
                <Select
                  value={String(pickerMonth)}
                  onValueChange={(v) => setPickerMonth(Number(v))}
                >
                  <SelectTrigger className="h-10 w-full" aria-label="ماه">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {PERSIAN_MONTHS.map((name, idx) => (
                      <SelectItem key={idx + 1} value={String(idx + 1)}>
                        {name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              {/* روز */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">روز</Label>
                <Select
                  value={String(pickerDay)}
                  onValueChange={(v) => setPickerDay(Number(v))}
                >
                  <SelectTrigger className="h-10 w-full" aria-label="روز">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    {dayOptions.map((d) => (
                      <SelectItem key={d} value={String(d)}>
                        {toFa(d)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setDateDialogOpen(false)}
              >
                انصراف
              </Button>
              <Button
                onClick={() => {
                  const d = jalaaliToDate(pickerYear, pickerMonth, pickerDay);
                  store_updateProfile({ startDate: isoDate(d) });
                  toast.success("تاریخ شروع به‌روزرسانی شد.");
                  setDateDialogOpen(false);
                }}
              >
                تأیید
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </SettingsCard>

      {/* ─────────────── 5. ظاهر ─────────────── */}
      <SettingsCard
        title="ظاهر"
        subtitle="حالت نمایش اپلیکیشن."
        icon={<Info className="size-4" />}
      >
        <div className="grid grid-cols-3 gap-2" role="radiogroup" aria-label="انتخاب ظاهر">
          {(
            [
              { value: "light", label: "روشن", icon: "Sun" },
              { value: "dark", label: "تاریک", icon: "Moon" },
              { value: "system", label: "سیستم", icon: "Monitor" },
            ] as const
          ).map((opt) => {
            const selected = state.settings.theme === opt.value;
            return (
              <button
                key={opt.value}
                type="button"
                role="radio"
                aria-checked={selected}
                onClick={() => {
                  store_updateSettings({ theme: opt.value });
                  setTheme(opt.value);
                  toast.success("ظاهر به‌روزرسانی شد.");
                }}
                className={cn(
                  "flex flex-col items-center justify-center gap-1.5 rounded-lg border p-3 transition-colors tap-safe",
                  selected
                    ? "border-primary bg-primary/5 text-primary"
                    : "border-border bg-card text-muted-foreground hover:bg-accent/40",
                )}
              >
                <Icon name={opt.icon} className="size-5" />
                <span className="text-xs font-medium">{opt.label}</span>
              </button>
            );
          })}
        </div>
        {!mounted ? (
          <p className="text-[11px] text-muted-foreground">
            در حال همگام‌سازی ظاهر…
          </p>
        ) : null}
      </SettingsCard>

      {/* ─────────────── 6. یادآور ─────────────── */}
      <SettingsCard
        title="یادآور"
        subtitle="یادآوری روزانه برای نمازهای قضا."
        icon={<Bell className="size-4" />}
      >
        <div className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card p-3.5">
          <div className="space-y-0.5">
            <p className="text-sm font-medium">فعال‌سازی یادآور</p>
            <p className="text-xs text-muted-foreground">
              یادآورها فقط زمانی که اپلیکیشن باز باشد فعال هستند.
            </p>
          </div>
          <Switch
            checked={reminders.enabled}
            onCheckedChange={(v) => {
              store_setReminder({ enabled: v });
              toast.success(v ? "یادآور فعال شد." : "یادآور غیرفعال شد.");
            }}
            aria-label="فعال‌سازی یادآور"
          />
        </div>

        {reminders.enabled ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-3">
              <Label htmlFor="reminder-time" className="text-sm font-medium">
                ساعت یادآور
              </Label>
              <Input
                id="reminder-time"
                type="time"
                dir="ltr"
                value={reminders.time}
                onChange={(e) => {
                  store_setReminder({ time: e.target.value });
                  toast.success("ساعت یادآور به‌روزرسانی شد.");
                }}
                className="h-10 w-32 text-center tabular-nums"
              />
            </div>

            <Separator />

            <div className="space-y-2">
              <PermissionStatus permission={reminders.permission} />
              {reminders.permission !== "granted" ? (
                <Button
                  variant="outline"
                  className="h-10 w-full gap-2"
                  onClick={async () => {
                    const result = await requestReminderPermission();
                    store_setReminder({ permission: result });
                    if (result === "granted") {
                      toast.success("اعلان‌ها فعال شدند.");
                    } else if (result === "denied") {
                      toast.error("دسترسی اعلان‌ها رد شد.");
                    } else if (result === "unsupported") {
                      toast.error("مرورگر شما از اعلان‌ها پشتیبانی نمی‌کند.");
                    }
                  }}
                >
                  <BellRing className="size-4" />
                  درخواست اجازه اعلان
                </Button>
              ) : null}
            </div>

            <p className="text-xs text-muted-foreground leading-relaxed">
              یادآورها فقط زمانی که اپلیکیشن باز باشد فعال هستند.
            </p>
          </div>
        ) : null}
      </SettingsCard>

      {/* ─────────────── 7. دستاوردها ─────────────── */}
      <SettingsCard
        title="دستاوردها"
        subtitle="نمای کلی از دستاوردهای بازشده و قفل‌شده."
        icon={<Info className="size-4" />}
      >
        <div className="grid grid-cols-2 gap-2">
          {ACHIEVEMENTS.map((def) => {
            const unlocked = isAchievementEverUnlocked(state, def.id);
            return (
              <div
                key={def.id}
                className={cn(
                  "relative flex flex-col gap-1.5 rounded-lg border p-3 transition-colors",
                  unlocked
                    ? "border-gold/40 bg-gold/5"
                    : "border-border bg-muted/40 opacity-70",
                )}
              >
                <div className="flex items-center justify-between">
                  <span
                    className={cn(
                      "flex size-8 items-center justify-center rounded-md",
                      unlocked
                        ? "bg-gold/15 text-gold"
                        : "bg-muted text-muted-foreground",
                    )}
                  >
                    <Icon name={def.icon} className="size-4" />
                  </span>
                  {unlocked ? (
                    <span className="flex size-5 items-center justify-center rounded-full bg-success/15 text-success">
                      <Check className="size-3.5" />
                    </span>
                  ) : (
                    <span className="flex size-5 items-center justify-center rounded-full bg-muted text-muted-foreground">
                      <Lock className="size-3" />
                    </span>
                  )}
                </div>
                <p
                  className={cn(
                    "text-xs font-bold leading-tight",
                    unlocked ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  {def.title}
                </p>
                <p className="text-[11px] text-muted-foreground leading-snug">
                  {def.description}
                </p>
              </div>
            );
          })}
        </div>
        <p className="text-xs text-muted-foreground">
          تعداد بازشده:{" "}
          <PersianNumber
            value={
              ACHIEVEMENTS.filter((a) =>
                isAchievementEverUnlocked(state, a.id),
              ).length
            }
          />
          {" از "}
          <PersianNumber value={ACHIEVEMENTS.length} />
        </p>
      </SettingsCard>

      {/* ─────────────── 8. داده‌ها ─────────────── */}
      <SettingsCard
        title="داده‌ها"
        subtitle="مدیریت داده‌های اپلیکیشن."
        icon={<ShieldAlert className="size-4" />}
      >
        <div className="space-y-2">
          <Button
            variant="outline"
            className="h-11 w-full justify-start gap-2"
            onClick={() => setReplayOpen(true)}
          >
            <RotateCcw className="size-4" />
            بازپخش آموزش
          </Button>
          <ConfirmDialog
            open={replayOpen}
            onOpenChange={setReplayOpen}
            title="آماده پخش آموزش از ابتدا؟"
            description="آموزش از ابتدا پخش خواهد شد. داده‌ها و پیشرفت شما حفظ می‌شوند."
            confirmText="پخش آموزش"
            onConfirm={() => {
              store_replayOnboarding();
              toast.success("آموزش از ابتدا پخش می‌شود.");
              setReplayOpen(false);
            }}
          />

          <Button
            variant="destructive"
            className="h-11 w-full justify-start gap-2"
            onClick={() => setResetOpen(true)}
          >
            <Trash2 className="size-4" />
            بازنشانی کامل
          </Button>
          <ConfirmDialog
            open={resetOpen}
            onOpenChange={setResetOpen}
            title="بازنشانی کامل اپلیکیشن"
            description="تمام سوابق، آمار، XP و پیشرفت شما حذف خواهد شد. این عمل بازگشت‌ناپذیر است."
            confirmText="بازنشانی کامل"
            destructive
            onConfirm={() => {
              store_resetAll();
              toast.success("همه چیز بازنشانی شد.");
              setResetOpen(false);
            }}
          />
        </div>
      </SettingsCard>

      {/* ─────────────── 9. درباره اپلیکیشن ─────────────── */}
      <Card className="shadow-none">
        <CardContent className="p-5 space-y-4">
          <div className="flex items-center gap-2.5">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Info className="size-4" />
            </span>
            <h3 className="text-base font-bold">درباره اپلیکیشن</h3>
          </div>

          <div className="space-y-1">
            <div className="flex items-baseline gap-2">
              <p className="text-lg font-bold font-display">محراب</p>
              <span className="text-xs text-muted-foreground">
                نسخه <PersianNumber value={APP_VERSION} />
              </span>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              محراب، همراه تو در مسیر نمازهای قضا و اذکار. این اپلیکیشن به‌صورت
              محلی و بدون نیاز به اینترنت کار می‌کند.
            </p>
          </div>

          <Separator />

          <div className="rounded-lg bg-muted p-3.5 space-y-1">
            <p className="text-[11px] text-muted-foreground">درباره سازنده</p>
            <p className="text-sm font-medium tracking-wide">
              سازنده: 𝓜𝓸𝓱𝓪𝓶𝓶𝓪𝓭 𝓗𝓸𝓼𝓼𝓮𝓲𝓷
            </p>
          </div>

          <div className="flex items-start gap-2 rounded-lg bg-success/5 p-3 text-success/90">
            <ShieldCheck className="size-4 mt-0.5 shrink-0" />
            <p className="text-xs leading-relaxed">
              تمام داده‌های شما به‌صورت محلی در همین مرورگر ذخیره می‌شوند و به
              هیچ سروری ارسال نمی‌شوند.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ───────────────────────── permission status ─────────────────────────

function PermissionStatus({
  permission,
}: {
  permission: "default" | "granted" | "denied" | "unsupported";
}) {
  if (permission === "granted") {
    return (
      <div className="flex items-center gap-2 rounded-lg bg-success/10 p-3 text-success">
        <ShieldCheck className="size-4 shrink-0" />
        <p className="text-xs leading-relaxed">اعلان‌ها فعال شدند.</p>
      </div>
    );
  }
  if (permission === "denied") {
    return (
      <div className="flex items-start gap-2 rounded-lg bg-destructive/10 p-3 text-destructive">
        <ShieldAlert className="size-4 mt-0.5 shrink-0" />
        <p className="text-xs leading-relaxed">
          دسترسی اعلان‌ها رد شده است. لطفاً از تنظیمات مرورگر اجازه دهید.
        </p>
      </div>
    );
  }
  if (permission === "unsupported") {
    return (
      <div className="flex items-start gap-2 rounded-lg bg-muted p-3 text-muted-foreground">
        <ShieldAlert className="size-4 mt-0.5 shrink-0" />
        <p className="text-xs leading-relaxed">
          مرورگر شما از اعلان‌ها پشتیبانی نمی‌کند.
        </p>
      </div>
    );
  }
  // default
  return (
    <div className="flex items-start gap-2 rounded-lg bg-muted p-3 text-muted-foreground">
      <Bell className="size-4 mt-0.5 shrink-0" />
      <p className="text-xs leading-relaxed">
        اعلان‌ها فعال نیستند. روی «درخواست اجازه اعلان» بزنید.
      </p>
    </div>
  );
}
