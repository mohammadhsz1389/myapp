"use client";

import * as React from "react";
import { motion } from "framer-motion";
import {
  Plus,
  Minus,
  RotateCcw,
  Sparkles,
  Star,
  History,
  TrendingUp,
} from "lucide-react";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SectionTitle } from "@/components/common/section-title";
import { EmptyState } from "@/components/common/empty-state";
import { PersianNumber } from "@/components/common/persian-number";
import { ConfirmDialog } from "@/components/common/confirm-dialog";

import { useStore } from "@/lib/store";
import {
  totalDhikrCount,
  dhikrCountByType,
  dhikrInternalPoints,
  dhikrCountToday,
} from "@/lib/calculations";
import { DHIKR_LIST, DHIKR_MAP, DHIKR_KEYS } from "@/lib/config";
import { toFa, todayIso, jalaaliLong } from "@/lib/persian";
import { cn } from "@/lib/utils";
import type { DhikrKey } from "@/lib/types";

export default function DhikrView() {
  const s = useStore();

  const [selectedType, setSelectedType] = React.useState<DhikrKey>("salawat");
  const [confirmReset, setConfirmReset] = React.useState(false);

  const def = DHIKR_MAP[selectedType];
  const todayKey = todayIso();
  const todayCount = s.dhikr[todayKey]?.[selectedType] ?? 0;

  const totalPoints = dhikrInternalPoints(s);
  const totalCount = totalDhikrCount(s);
  const countsByType = dhikrCountByType(s);
  const todayAll = dhikrCountToday(s);

  // Build dhikr history (newest date first).
  const historyList = React.useMemo(() => {
    const out: { date: string; type: DhikrKey; count: number }[] = [];
    const dates = Object.keys(s.dhikr).sort((a, b) => (a < b ? 1 : -1));
    for (const date of dates) {
      const day = s.dhikr[date];
      if (!day) continue;
      for (const k of DHIKR_KEYS) {
        const count = day[k] ?? 0;
        if (count > 0) out.push({ date, type: k, count });
      }
    }
    return out;
  }, [s.dhikr]);

  return (
    <main
      dir="rtl"
      className="mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24"
    >
      <SectionTitle
        title="اذکار و اعمال"
        subtitle="شمارندهٔ سریع صلوات، توحید و حمد"
      />

      {/* ── 1. Dhikr segmented selector ── */}
      <div
        role="tablist"
        aria-label="انتخاب ذکر"
        className="grid grid-cols-3 gap-1.5 p-1 bg-muted rounded-xl"
      >
        {DHIKR_LIST.map((d) => {
          const active = selectedType === d.key;
          return (
            <button
              key={d.key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setSelectedType(d.key)}
              className={cn(
                "tap-safe py-2.5 rounded-lg text-sm font-medium transition-all min-h-[44px]",
                active
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground",
              )}
            >
              {d.name}
            </button>
          );
        })}
      </div>

      {/* ── 2. Big counter card ── */}
      <Card className="p-5 gap-4">
        <div className="text-center space-y-2">
          <h3 className="text-xl font-bold text-foreground">{def.name}</h3>
          <p
            dir="rtl"
            lang="ar"
            className="text-lg leading-loose text-foreground/80 font-display"
          >
            {def.arabic}
          </p>
          <p className="text-xs text-muted-foreground">
            امتیاز داخلی هر مورد:{" "}
            <span className="font-medium text-foreground">
              <PersianNumber value={def.internalPoints} />
            </span>
          </p>
          <p className="text-[11px] text-muted-foreground/80 leading-relaxed max-w-xs mx-auto">
            این امتیاز، سیستم امتیازدهی داخلی اپلیکیشن است و ادعای پاداش قطعی
            الهی نیست.
          </p>
        </div>

        <div className="text-center py-2">
          <PersianNumber
            value={todayCount}
            className="text-7xl font-bold text-foreground tabular-nums"
          />
        </div>

        <motion.button
          type="button"
          onClick={() => s.incrementDhikr(selectedType)}
          whileTap={{ scale: 0.96 }}
          transition={{ duration: 0.1, ease: "easeOut" }}
          aria-label="افزایش شمارنده"
          className="tap-safe w-full h-20 rounded-2xl bg-primary text-primary-foreground text-3xl font-bold flex items-center justify-center gap-2 shadow-sm active:shadow-none transition-shadow"
        >
          <Plus className="size-7" strokeWidth={2.6} />
          <span>افزودن</span>
        </motion.button>

        <div className="grid grid-cols-2 gap-2">
          <Button
            type="button"
            variant="outline"
            disabled={todayCount === 0}
            onClick={() => s.decrementDhikr(selectedType)}
            className="min-h-[44px]"
          >
            <Minus className="size-4" />
            برگشت
          </Button>
          <Button
            type="button"
            variant="ghost"
            disabled={todayCount === 0}
            onClick={() => setConfirmReset(true)}
            className="min-h-[44px] text-destructive hover:text-destructive hover:bg-destructive/5"
          >
            <RotateCcw className="size-4" />
            شروع مجدد
          </Button>
        </div>
      </Card>

      <ConfirmDialog
        open={confirmReset}
        onOpenChange={setConfirmReset}
        title="صفر کردن ذکر امروز"
        description={
          <>
            آیا «{def.name}» امروز صفر شود؟ این عمل قابل بازگشت نیست.
          </>
        }
        destructive
        confirmText="بله، صفر شود"
        cancelText="انصراف"
        onConfirm={() => {
          s.resetDhikrDay(todayKey, selectedType);
          setConfirmReset(false);
        }}
      />

      {/* ── 3. Today summary row ── */}
      <Card className="p-4 gap-3">
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">خلاصهٔ امروز</p>
          <p className="text-xs text-muted-foreground">
            مجموع: <PersianNumber value={todayAll} />
          </p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {DHIKR_LIST.map((d) => {
            const c = s.dhikr[todayKey]?.[d.key] ?? 0;
            const active = selectedType === d.key;
            return (
              <div
                key={d.key}
                className={cn(
                  "rounded-lg p-2.5 text-center transition-all",
                  active
                    ? "bg-primary/10 ring-1 ring-primary/40"
                    : "bg-muted",
                )}
              >
                <p className="text-[11px] text-muted-foreground leading-tight">
                  {d.name}
                </p>
                <p className="text-xl font-bold text-foreground tabular-nums mt-1">
                  <PersianNumber value={c} />
                </p>
                <p className="text-[10px] text-muted-foreground">امروز</p>
              </div>
            );
          })}
        </div>
      </Card>

      {/* ── 4. Total points card (gold accent) ── */}
      <Card className="p-5 gap-3 border-gold/40 bg-gold/5">
        <div className="flex items-start justify-between gap-3">
          <div className="space-y-1">
            <p className="text-xs text-muted-foreground">
              امتیاز داخلی کل اذکار
            </p>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-bold tabular-nums text-gold">
                <PersianNumber value={totalPoints} />
              </span>
              <span className="text-xs text-muted-foreground">امتیاز</span>
            </div>
          </div>
          <div className="size-10 rounded-xl bg-gold/15 text-gold flex items-center justify-center shrink-0">
            <Star className="size-5" />
          </div>
        </div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          معادل XP در سیستم پیشرفت. مجموع ذکرهای ثبت‌شده:{" "}
          <PersianNumber value={totalCount} /> مرتبه.
        </p>
        <div className="grid grid-cols-3 gap-2 pt-1">
          {DHIKR_LIST.map((d) => (
            <div
              key={d.key}
              className="rounded-lg bg-background/60 p-2 text-center"
            >
              <p className="text-[10px] text-muted-foreground">{d.name}</p>
              <p className="text-sm font-bold text-foreground tabular-nums">
                <PersianNumber value={countsByType[d.key] ?? 0} />
              </p>
            </div>
          ))}
        </div>
      </Card>

      {/* ── 5. History list ── */}
      <Card className="p-4 gap-3">
        <SectionTitle
          title="تاریخچه اذکار"
          subtitle="آخرین ثبت‌ها از جدیدترین به قدیمی"
          action={<History className="size-4 text-muted-foreground" />}
        />
        {historyList.length === 0 ? (
          <EmptyState
            icon="Sparkles"
            title="هنوز ذکری ثبت نشده است."
            description="با دکمه + شروع به شمارش کن."
            className="py-6"
          />
        ) : (
          <ul className="max-h-96 overflow-y-auto slim-scroll space-y-1.5 pr-1">
            {historyList.map((h) => {
              const d = DHIKR_MAP[h.type];
              const dateLabel = jalaaliLong(new Date(h.date));
              return (
                <li
                  key={`${h.date}-${h.type}`}
                  className="flex items-center justify-between gap-3 rounded-lg border border-border bg-background px-3 py-2.5"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="size-9 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                      <Sparkles className="size-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium text-foreground truncate">
                        {d.name}
                      </p>
                      <p className="text-[11px] text-muted-foreground truncate">
                        {dateLabel}
                      </p>
                    </div>
                  </div>
                  <div className="text-left shrink-0">
                    <p className="text-base font-bold text-foreground tabular-nums">
                      <PersianNumber value={h.count} />
                    </p>
                    <p className="text-[10px] text-muted-foreground">مرتبه</p>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </Card>

      {/* ── Helper footer hint ── */}
      <div className="flex items-center justify-center gap-2 text-[11px] text-muted-foreground pt-1">
        <TrendingUp className="size-3.5" />
        <span>
          هر ذکر به‌صورت لحظه‌ای در سیستم پیشرفت اعمال می‌شود. (هر{" "}
          {toFa(def.internalPoints)} امتیاز داخلی ≈ {toFa(def.internalPoints / 100)}{" "}
          XP)
        </span>
      </div>
    </main>
  );
}
