"use client";

import * as React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
  AreaChart,
  Area,
  CartesianGrid,
} from "recharts";
import {
  Flame,
  Trophy,
  Award,
  CalendarDays,
  Target,
  Activity,
  CheckCircle2,
  BookOpenCheck,
  BarChart3,
  ChevronRight,
  ChevronLeft,
  Sparkles,
  CalendarCheck,
  TrendingUp,
  Clock,
} from "lucide-react";

import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatCard } from "@/components/common/stat-card";
import { SectionTitle } from "@/components/common/section-title";
import { EmptyState } from "@/components/common/empty-state";
import { PersianNumber } from "@/components/common/persian-number";

import { useStore } from "@/lib/store";
import {
  completedDayCount,
  remainingDays,
  completedPrayerCount,
  totalRakat,
  overallProgress,
  currentStreak,
  longestStreak,
  totalXp,
  levelInfo,
  activeDaysCount,
  bestDay,
  prayerCountsByType,
  calendarDayStatus,
  personalPath,
  estimation,
  recentActivity,
  weeklyActivity,
  monthlyActivity,
  totalQadaDays,
} from "@/lib/calculations";
import { PRAYERS, PRAYER_KEYS } from "@/lib/config";
import {
  toFa,
  jalaaliLong,
  jalaaliToDate,
  toJalaali,
  isoDate,
  PERSIAN_MONTHS,
  WEEKDAYS_SHORT_FA,
  isJalaaliLeap,
} from "@/lib/persian";
import { cn } from "@/lib/utils";

// Persian-week-ordered weekday headers (Sat → Fri)
const PERSIAN_WEEK_HEADERS = [6, 0, 1, 2, 3, 4, 5].map(
  (i) => WEEKDAYS_SHORT_FA[i],
);

const CHART_COLORS = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

type TabKey = "weekly" | "monthly" | "overall";

export default function StatsView() {
  const s = useStore();
  const [tab, setTab] = React.useState<TabKey>("weekly");

  // Calendar display month (defaults to current Jalali month)
  const today = React.useMemo(() => new Date(), []);
  const todayJ = React.useMemo(() => toJalaali(today), [today]);
  const [displayMonth, setDisplayMonth] = React.useState({
    jy: todayJ.jy,
    jm: todayJ.jm,
  });

  // ── Overview stats ──
  const total = totalQadaDays(s);
  const completed = completedDayCount(s);
  const remaining = remainingDays(s);
  const prayersCompleted = completedPrayerCount(s);
  const rakat = totalRakat(s);
  const progress = overallProgress(s);
  const progressRound = Math.round(progress);
  const streak = currentStreak(s);
  const longest = longestStreak(s);
  const xp = totalXp(s);
  const level = levelInfo(s);
  const activeDays = activeDaysCount(s);
  const best = bestDay(s);

  // incomplete days: qada days with some but not all prayers done
  let incompleteDays = 0;
  for (const key of Object.keys(s.qadaDays)) {
    const day = s.qadaDays[Number(key)];
    const doneCount = PRAYER_KEYS.filter(
      (k) => day.prayers[k]?.done,
    ).length;
    if (doneCount > 0 && doneCount < PRAYER_KEYS.length) incompleteDays++;
  }

  // ── Prayer distribution ──
  const prayerCounts = prayerCountsByType(s);
  const prayerChart = PRAYERS.map((p) => ({
    name: p.shortName,
    count: prayerCounts[p.key],
  }));
  const hasPrayerData = prayerChart.some((d) => d.count > 0);

  // ── Activity chart data ──
  const activityDays =
    tab === "weekly"
      ? weeklyActivity(s)
      : tab === "monthly"
        ? monthlyActivity(s)
        : recentActivity(s, 90);
  const activityChart = activityDays.map((d) => {
    const date = new Date(d.date + "T00:00:00");
    const label =
      tab === "weekly"
        ? WEEKDAYS_SHORT_FA[date.getDay()]
        : toFa(d.jalaali.jd);
    return { label, prayers: d.prayers };
  });
  const hasActivity = activityChart.some((d) => d.prayers > 0);
  const xInterval = tab === "weekly" ? 0 : tab === "monthly" ? 4 : 14;

  // ── Calendar grid ──
  const { offset, daysInMonth } = computeMonthGrid(
    displayMonth.jy,
    displayMonth.jm,
  );

  // ── Personal path ──
  const path = personalPath(s);

  // ── Estimation ──
  const est = estimation(s);

  // Handlers
  const goPrevMonth = () => {
    setDisplayMonth((m) =>
      m.jm === 1 ? { jy: m.jy - 1, jm: 12 } : { jy: m.jy, jm: m.jm - 1 },
    );
  };
  const goNextMonth = () => {
    setDisplayMonth((m) =>
      m.jm === 12 ? { jy: m.jy + 1, jm: 1 } : { jy: m.jy, jm: m.jm + 1 },
    );
  };
  const resetMonth = () => setDisplayMonth({ jy: todayJ.jy, jm: todayJ.jm });

  return (
    <main
      dir="rtl"
      className="mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24"
    >
      <SectionTitle
        title="آمار و پیشرفت"
        subtitle="نگاهی دقیق به مسیر قضای تو"
      />

      {/* ── Period tabs ── */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as TabKey)}>
        <TabsList className="w-full grid-cols-3">
          <TabsTrigger value="weekly" className="min-h-[36px]">
            هفتگی
          </TabsTrigger>
          <TabsTrigger value="monthly" className="min-h-[36px]">
            ماهانه
          </TabsTrigger>
          <TabsTrigger value="overall" className="min-h-[36px]">
            کلی
          </TabsTrigger>
        </TabsList>
      </Tabs>

      {/* ── 1. Overview stats grid ── */}
      <section className="space-y-3">
        <SectionTitle title="نمای کلی" />
        <div className="grid grid-cols-2 gap-2.5">
          <StatCard
            label="روزهای انجام‌شده"
            value={<PersianNumber value={completed} />}
            unit="روز"
            icon={<CheckCircle2 className="size-4" />}
            accent={completed > 0 ? "primary" : "default"}
          />
          <StatCard
            label="روزهای باقی‌مانده"
            value={<PersianNumber value={remaining} />}
            unit="روز"
            icon={<CalendarDays className="size-4" />}
          />
          <StatCard
            label="نمازهای کامل‌شده"
            value={<PersianNumber value={prayersCompleted} />}
            unit="نماز"
            icon={<BookOpenCheck className="size-4" />}
          />
          <StatCard
            label="کل رکعات"
            value={<PersianNumber value={rakat} />}
            unit="رکعت"
            icon={<Activity className="size-4" />}
          />
          <StatCard
            label="روزهای ناقص"
            value={<PersianNumber value={incompleteDays} />}
            unit="روز"
            hint="روزهایی که بخشی از نمازهایشان انجام شده"
            icon={<Clock className="size-4" />}
          />
          <StatCard
            label="پیشرفت کلی"
            value={<PersianNumber value={progressRound} />}
            unit="٪"
            icon={<Target className="size-4" />}
            accent={progressRound > 0 ? "primary" : "default"}
          />
          <StatCard
            label="استریک فعلی"
            value={<PersianNumber value={streak} />}
            unit="روز"
            icon={<Flame className="size-4" />}
            accent={streak > 0 ? "gold" : "default"}
          />
          <StatCard
            label="طولانی‌ترین استریک"
            value={<PersianNumber value={longest} />}
            unit="روز"
            icon={<Flame className="size-4" />}
          />
          <StatCard
            label="امتیاز (XP)"
            value={<PersianNumber value={xp} />}
            icon={<Award className="size-4" />}
            accent="gold"
          />
          <StatCard
            label="سطح"
            value={
              <span className="text-lg">
                <PersianNumber value={level.level} separator={false} />
              </span>
            }
            hint={level.name}
            icon={<Trophy className="size-4" />}
            accent="gold"
          />
          <StatCard
            label="روزهای فعال"
            value={<PersianNumber value={activeDays} />}
            unit="روز"
            icon={<CalendarCheck className="size-4" />}
          />
          <StatCard
            label="بهترین روز"
            value={
              best ? (
                <PersianNumber value={best.prayers} />
              ) : (
                <span className="text-muted-foreground">—</span>
              )
            }
            unit={best ? "نماز" : undefined}
            icon={<Trophy className="size-4" />}
          />
        </div>
      </section>

      {/* ── 2. Prayer distribution chart ── */}
      <Card className="p-4 gap-3">
        <SectionTitle
          title="توزیع نمازها"
          subtitle="تعداد هر نماز قضای انجام‌شده"
        />
        {hasPrayerData ? (
          <div className="w-full overflow-hidden">
            <ResponsiveContainer width="100%" height={224}>
              <BarChart
                data={prayerChart}
                margin={{ top: 8, right: 8, left: 8, bottom: 0 }}
              >
                <CartesianGrid
                  strokeDasharray="3 3"
                  vertical={false}
                  stroke="var(--border)"
                />
                <XAxis
                  dataKey="name"
                  reversed
                  tickLine={false}
                  axisLine={false}
                  tick={{ fontSize: 12, fill: "var(--muted-foreground)" }}
                />
                <YAxis
                  allowDecimals={false}
                  tickLine={false}
                  axisLine={false}
                  width={28}
                  tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                  tickFormatter={(v) => toFa(v)}
                />
                <Tooltip
                  cursor={{ fill: "var(--muted)", opacity: 0.4 }}
                  content={<ChartTooltip unit="نماز" />}
                />
                <Bar dataKey="count" radius={[6, 6, 0, 0]} maxBarSize={48}>
                  {prayerChart.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <EmptyState
            icon="BarChart3"
            title="هنوز داده کافی برای نمایش این نمودار وجود ندارد."
            description="با تکمیل نمازهای قضا، این نمودار تکمیل می‌شود."
            className="py-6"
          />
        )}
      </Card>

      {/* ── 3. Activity chart ── */}
      <Card className="p-4 gap-3">
        <SectionTitle
          title="فعالیت اخیر"
          subtitle={
            tab === "weekly"
              ? "۷ روز گذشته"
              : tab === "monthly"
                ? "۳۰ روز گذشته"
                : "۹۰ روز گذشته"
          }
        />
        {hasActivity ? (
          <div className="w-full overflow-hidden">
            <ResponsiveContainer width="100%" height={224}>
              {tab === "weekly" ? (
                <BarChart
                  data={activityChart}
                  margin={{ top: 8, right: 8, left: 8, bottom: 0 }}
                >
                  <CartesianGrid
                    strokeDasharray="3 3"
                    vertical={false}
                    stroke="var(--border)"
                  />
                  <XAxis
                    dataKey="label"
                    reversed
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 12, fill: "var(--muted-foreground)" }}
                    interval={xInterval}
                  />
                  <YAxis
                    allowDecimals={false}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                    tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                    tickFormatter={(v) => toFa(v)}
                  />
                  <Tooltip
                    cursor={{ fill: "var(--muted)", opacity: 0.4 }}
                    content={<ChartTooltip unit="نماز" />}
                  />
                  <Bar
                    dataKey="prayers"
                    fill="var(--chart-1)"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={36}
                  />
                </BarChart>
              ) : (
                <AreaChart
                  data={activityChart}
                  margin={{ top: 8, right: 8, left: 8, bottom: 0 }}
                >
                  <defs>
                    <linearGradient id="activityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop
                        offset="0%"
                        stopColor="var(--chart-1)"
                        stopOpacity={0.4}
                      />
                      <stop
                        offset="100%"
                        stopColor="var(--chart-1)"
                        stopOpacity={0.02}
                      />
                    </linearGradient>
                  </defs>
                  <CartesianGrid
                    strokeDasharray="3 3"
                    vertical={false}
                    stroke="var(--border)"
                  />
                  <XAxis
                    dataKey="label"
                    reversed
                    tickLine={false}
                    axisLine={false}
                    tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                    interval={xInterval}
                  />
                  <YAxis
                    allowDecimals={false}
                    tickLine={false}
                    axisLine={false}
                    width={28}
                    tick={{ fontSize: 11, fill: "var(--muted-foreground)" }}
                    tickFormatter={(v) => toFa(v)}
                  />
                  <Tooltip
                    cursor={{ stroke: "var(--chart-1)", strokeWidth: 1 }}
                    content={<ChartTooltip unit="نماز" />}
                  />
                  <Area
                    type="monotone"
                    dataKey="prayers"
                    stroke="var(--chart-1)"
                    strokeWidth={2}
                    fill="url(#activityGrad)"
                    dot={false}
                    activeDot={{ r: 4, fill: "var(--chart-1)" }}
                  />
                </AreaChart>
              )}
            </ResponsiveContainer>
          </div>
        ) : (
          <EmptyState
            icon="Activity"
            title="هنوز داده کافی برای نمایش این نمودار وجود ندارد."
            description="با ثبت نمازهای قضا در روزهای اخیر، این نمودار تکمیل می‌شود."
            className="py-6"
          />
        )}
      </Card>

      {/* ── 4. Calendar ── */}
      <Card className="p-4 gap-3">
        <div className="flex items-center justify-between gap-2">
          <div className="space-y-0.5">
            <h3 className="text-base font-bold text-foreground leading-tight">
              تقویم فعالیت
            </h3>
            <p className="text-xs text-muted-foreground">
              وضعیت هر روز از منظر هدف روزانه
            </p>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={goPrevMonth}
              aria-label="ماه قبل"
              className="size-9"
            >
              <ChevronRight className="size-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={goNextMonth}
              aria-label="ماه بعد"
              className="size-9"
            >
              <ChevronLeft className="size-5" />
            </Button>
          </div>
        </div>

        <div className="text-center">
          <button
            type="button"
            onClick={resetMonth}
            className="tap-safe inline-flex items-center gap-1 text-sm font-medium text-foreground hover:text-primary transition-colors"
          >
            <CalendarDays className="size-4 text-muted-foreground" />
            {PERSIAN_MONTHS[displayMonth.jm - 1]}{" "}
            <PersianNumber value={displayMonth.jy} separator={false} />
          </button>
        </div>

        {/* Weekday headers */}
        <div className="grid grid-cols-7 gap-1 mt-1">
          {PERSIAN_WEEK_HEADERS.map((w, i) => (
            <div
              key={i}
              className="text-center text-[11px] text-muted-foreground font-medium py-1"
            >
              {w}
            </div>
          ))}
        </div>

        {/* Days grid */}
        <div className="grid grid-cols-7 gap-1">
          {Array.from({ length: offset }).map((_, i) => (
            <div key={`b-${i}`} className="aspect-square" />
          ))}
          {Array.from({ length: daysInMonth }).map((_, idx) => {
            const day = idx + 1;
            const date = jalaaliToDate(displayMonth.jy, displayMonth.jm, day);
            const dateStr = isoDate(date);
            const info = calendarDayStatus(s, dateStr);
            const isToday =
              todayJ.jy === displayMonth.jy &&
              todayJ.jm === displayMonth.jm &&
              todayJ.jd === day;
            return (
              <div
                key={`d-${day}`}
                title={`${toFa(info.prayerCount)} نماز`}
                className={cn(
                  "tap-safe aspect-square rounded-lg flex flex-col items-center justify-center text-xs transition-colors relative",
                  info.status === "complete" &&
                    "bg-primary text-primary-foreground font-bold",
                  info.status === "partial" &&
                    "bg-gold/15 text-gold-foreground font-medium ring-1 ring-gold/30",
                  info.status === "none" &&
                    "bg-muted/50 text-muted-foreground",
                  isToday && "ring-2 ring-primary/70",
                )}
              >
                <PersianNumber value={day} separator={false} />
                {info.status === "partial" ? (
                  <span className="size-1 rounded-full bg-gold mt-0.5" />
                ) : null}
                {info.status === "complete" ? (
                  <span className="size-1 rounded-full bg-primary-foreground/80 mt-0.5" />
                ) : null}
              </div>
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex items-center justify-center gap-4 text-[11px] text-muted-foreground pt-1">
          <span className="flex items-center gap-1.5">
            <span className="size-2.5 rounded-sm bg-primary" />
            کامل
          </span>
          <span className="flex items-center gap-1.5">
            <span className="size-2.5 rounded-sm bg-gold/40 ring-1 ring-gold/30" />
            ناقص
          </span>
          <span className="flex items-center gap-1.5">
            <span className="size-2.5 rounded-sm bg-muted" />
            بدون فعالیت
          </span>
        </div>
      </Card>

      {/* ── 5. مسیر من (personal path) ── */}
      <Card className="p-4 gap-3">
        <SectionTitle
          title="مسیر من"
          subtitle="نقاط عطف سفر قضا از شروع تا پایان"
        />
        {path.length === 0 ? (
          <EmptyState
            icon="Footprints"
            title="هنوز مسیری تعریف نشده است."
            description="با راه‌اندازی پروفایل، مسیر شخصی تو مشخص می‌شود."
            className="py-6"
          />
        ) : (
          <div className="relative pl-1">
            {/* Full-height vertical line behind nodes (right side, RTL) */}
            <div
              aria-hidden
              className="absolute top-4 bottom-4 right-4 w-0.5 bg-border"
            />
            <ul className="space-y-4 relative">
              {path.map((m, i) => {
                const reached = m.isReached;
                const current = m.isCurrent;
                return (
                  <li
                    key={i}
                    className="flex items-center gap-3 relative"
                  >
                    <div
                      className={cn(
                        "size-8 rounded-full flex items-center justify-center z-10 border-2 shrink-0 transition-all",
                        reached && !current
                          ? "bg-primary border-primary text-primary-foreground"
                          : current
                            ? "bg-background border-gold ring-4 ring-gold/20"
                            : "bg-background border-border text-muted-foreground",
                      )}
                    >
                      {reached && !current ? (
                        <CheckCircle2 className="size-4" strokeWidth={2.5} />
                      ) : current ? (
                        <span className="size-2.5 rounded-full bg-gold animate-pulse" />
                      ) : (
                        <span className="size-2 rounded-full bg-muted-foreground/40" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p
                        className={cn(
                          "text-sm font-medium leading-tight",
                          current
                            ? "text-foreground"
                            : reached
                              ? "text-foreground"
                              : "text-muted-foreground",
                        )}
                      >
                        {m.label}
                        {current ? (
                          <span className="text-gold mr-1.5">· نقطهٔ فعلی</span>
                        ) : null}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">
                        {reached
                          ? "رسیده"
                          : `حدود ${toFa(m.daysRemaining)} روز دیگر`}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        )}
      </Card>

      {/* ── 6. Estimation ── */}
      <Card
        className={cn(
          "p-4 gap-2",
          est.hasEnoughData
            ? "border-primary/30 bg-primary/5"
            : "border-dashed",
        )}
      >
        <SectionTitle
          title="اگر با همین روند ادامه بدهم..."
          action={<TrendingUp className="size-4 text-muted-foreground" />}
        />
        {est.hasEnoughData ? (
          <div className="space-y-2 pt-1">
            <p className="text-sm text-foreground leading-relaxed">
              با میانگین{" "}
              <span className="font-bold text-primary">
                <PersianNumber
                  value={Number(est.avgPrayersPerDay!.toFixed(1))}
                  separator={false}
                />
              </span>{" "}
              نماز در روز، حدوداً در تاریخ{" "}
              <span className="font-bold text-foreground">
                {jalaaliLong(est.estimatedFinishDate!)}
              </span>{" "}
              مسیر قضا را کامل می‌کنی.
            </p>
            <div className="flex items-center justify-between rounded-lg bg-background/60 px-3 py-2">
              <span className="text-xs text-muted-foreground">
                روزهای باقی‌مانده (تخمینی)
              </span>
              <span className="text-base font-bold text-foreground tabular-nums">
                <PersianNumber value={est.estimatedDaysLeft!} /> روز
              </span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              این تخمین بر اساس فعالیت اخیر توست و قطعی نیست.
            </p>
          </div>
        ) : (
          <p className="text-sm text-muted-foreground leading-relaxed pt-1">
            {est.reason}
          </p>
        )}
      </Card>

      {/* ── Footer hint ── */}
      <div className="flex items-center justify-center gap-2 text-[11px] text-muted-foreground pt-1">
        <Sparkles className="size-3.5" />
        <span>
          کل: <PersianNumber value={total} /> روز قضا ·{" "}
          <PersianNumber value={prayersCompleted} /> نماز ·{" "}
          <PersianNumber value={rakat} /> رکعت
        </span>
      </div>
    </main>
  );
}

// ── Local helpers ──

function computeMonthGrid(jy: number, jm: number): {
  offset: number;
  daysInMonth: number;
} {
  // Persian week starts Saturday. JS getDay: Sat=6, Sun=0..Fri=5.
  // offset = (getDay + 1) % 7 → Sat=0, Sun=1, ..., Fri=6
  const first = jalaaliToDate(jy, jm, 1);
  const offset = (first.getDay() + 1) % 7;
  let daysInMonth: number;
  if (jm <= 6) daysInMonth = 31;
  else if (jm <= 11) daysInMonth = 30;
  else daysInMonth = isJalaaliLeap(jy) ? 30 : 29;
  return { offset, daysInMonth };
}

// Custom recharts tooltip — converts numbers to Persian digits.
function ChartTooltip({
  active,
  payload,
  label,
  unit = "نماز",
}: {
  active?: boolean;
  payload?: Array<{ value: number; name?: string; color?: string }>;
  label?: string | number;
  unit?: string;
}) {
  if (!active || !payload || payload.length === 0) return null;
  return (
    <div className="bg-popover text-popover-foreground border border-border rounded-md px-2.5 py-1.5 text-xs shadow-md">
      {label != null && label !== "" ? (
        <p className="font-medium leading-tight">{label}</p>
      ) : null}
      {payload.map((p, i) => (
        <p key={i} className="text-muted-foreground leading-tight">
          <PersianNumber value={Number(p.value)} separator={false} /> {unit}
        </p>
      ))}
    </div>
  );
}
