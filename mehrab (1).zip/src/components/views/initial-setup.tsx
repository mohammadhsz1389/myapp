"use client";

import * as React from "react";
import { toast } from "sonner";
import { ChevronLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useStore } from "@/lib/store";
import { DAILY_GOAL_OPTIONS, MARJA_OPTIONS } from "@/lib/config";
import {
  PERSIAN_MONTHS,
  isJalaaliLeap,
  isoDate,
  jalaaliToDate,
  parseFaInt,
  toFa,
  toJalaali,
} from "@/lib/persian";

/** Number of days in a given Jalali month (1..12). */
function daysInJalaaliMonth(jy: number, jm: number): number {
  if (jm <= 6) return 31;
  if (jm <= 11) return 30;
  // jm === 12 → esfand: 30 in leap year, 29 otherwise
  return isJalaaliLeap(jy) ? 30 : 29;
}

export default function InitialSetup() {
  const setupProfile = useStore((s) => s.setupProfile);

  // Default start date = today (in Jalali).
  const today = React.useMemo(() => toJalaali(new Date()), []);

  const [totalQadaDaysInput, setTotalQadaDaysInput] = React.useState<string>("");
  const [jy, setJy] = React.useState<number>(today.jy);
  const [jm, setJm] = React.useState<number>(today.jm);
  const [jd, setJd] = React.useState<number>(today.jd);
  const [dailyGoal, setDailyGoal] = React.useState<number>(1);
  const [marja, setMarja] = React.useState<string>("بدون مرجع");

  // Validate total qada days: integer ≥ 1.
  const trimmedInput = totalQadaDaysInput.trim();
  const parsedTotal =
    trimmedInput === "" ? NaN : parseFaInt(totalQadaDaysInput);
  const isTotalValid =
    Number.isInteger(parsedTotal) && parsedTotal >= 1;
  const showTotalError = trimmedInput !== "" && !isTotalValid;

  // Clamp day to valid range for the selected month/year.
  const maxDay = daysInJalaaliMonth(jy, jm);
  const safeJd = Math.min(Math.max(1, jd), maxDay);

  // Year range: current Jalali year - 10 .. current Jalali year + 1
  const yearOptions = React.useMemo(() => {
    const arr: number[] = [];
    for (let y = today.jy + 1; y >= today.jy - 10; y--) {
      arr.push(y);
    }
    return arr;
  }, [today.jy]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isTotalValid) return;
    const day = Math.max(1, Math.min(safeJd, maxDay));
    const date = jalaaliToDate(jy, jm, day);
    const startDate = isoDate(date);
    setupProfile({
      totalQadaDays: parsedTotal,
      startDate,
      dailyGoal,
      marja,
    });
    toast.success("اطلاعات شما ذخیره شد.");
  };

  return (
    <div className="mx-auto w-full max-w-md space-y-5 px-4 py-4">
      {/* Header */}
      <header className="space-y-1.5 pt-2">
        <h1 className="font-display text-2xl text-foreground">
          بیایید شروع کنیم
        </h1>
        <p className="text-sm leading-6 text-muted-foreground">
          اطلاعات واقعی نمازهای قضای خود را وارد کنید. این مقادیر بعداً قابل تغییر
          هستند.
        </p>
      </header>

      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Total Qada Days */}
        <Card className="gap-4 p-5">
          <CardHeader className="px-0">
            <CardTitle>تعداد کل روزهای قضا</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 px-0">
            <Input
              inputMode="numeric"
              pattern="[۰-۹٠-٩0-9]*"
              value={totalQadaDaysInput}
              onChange={(e) => setTotalQadaDaysInput(e.target.value)}
              placeholder="۳۰۰"
              aria-invalid={showTotalError}
              className="h-11 text-base"
            />
            {showTotalError ? (
              <p className="text-xs leading-5 text-destructive" role="alert">
                لطفاً یک عدد صحیح بزرگتر از صفر وارد کنید.
              </p>
            ) : (
              <p className="text-xs leading-5 text-muted-foreground">
                مثلاً ۳۰۰
              </p>
            )}
          </CardContent>
        </Card>

        {/* Start Date — Jalali picker (year/month/day selects) */}
        <Card className="gap-4 p-5">
          <CardHeader className="px-0">
            <CardTitle>تاریخ شروع</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 px-0">
            <div className="grid grid-cols-3 gap-2">
              {/* Year */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">سال</Label>
                <Select
                  value={String(jy)}
                  onValueChange={(v) => setJy(Number(v))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {yearOptions.map((y) => (
                      <SelectItem key={y} value={String(y)}>
                        {toFa(y)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Month */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">ماه</Label>
                <Select
                  value={String(jm)}
                  onValueChange={(v) => setJm(Number(v))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PERSIAN_MONTHS.map((name, idx) => (
                      <SelectItem key={name} value={String(idx + 1)}>
                        {name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Day */}
              <div className="space-y-1.5">
                <Label className="text-xs text-muted-foreground">روز</Label>
                <Select
                  value={String(safeJd)}
                  onValueChange={(v) => setJd(Number(v))}
                >
                  <SelectTrigger className="w-full">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: maxDay }, (_, i) => i + 1).map(
                      (d) => (
                        <SelectItem key={d} value={String(d)}>
                          {toFa(d)}
                        </SelectItem>
                      ),
                    )}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <p className="text-xs leading-5 text-muted-foreground">
              تاریخ انتخابی: {toFa(safeJd)} {PERSIAN_MONTHS[jm - 1]} {toFa(jy)}
            </p>
          </CardContent>
        </Card>

        {/* Daily Goal */}
        <Card className="gap-4 p-5">
          <CardHeader className="px-0">
            <CardTitle>هدف روزانه</CardTitle>
          </CardHeader>
          <CardContent className="px-0">
            <RadioGroup
              value={String(dailyGoal)}
              onValueChange={(v) => setDailyGoal(Number(v))}
              className="gap-2"
            >
              {DAILY_GOAL_OPTIONS.map((opt) => {
                const id = `goal-${opt.value}`;
                return (
                  <Label
                    key={opt.value}
                    htmlFor={id}
                    className="flex cursor-pointer items-center gap-3 rounded-lg border border-border p-3 transition-colors hover:bg-accent/50 has-[[data-state=checked]]:border-primary has-[[data-state=checked]]:bg-primary/5"
                  >
                    <RadioGroupItem id={id} value={String(opt.value)} />
                    <span className="text-sm leading-6">{opt.label}</span>
                  </Label>
                );
              })}
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Marja */}
        <Card className="gap-4 p-5">
          <CardHeader className="px-0">
            <CardTitle>مرجع تقلید</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 px-0">
            <Select value={marja} onValueChange={setMarja}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MARJA_OPTIONS.map((m) => (
                  <SelectItem key={m} value={m}>
                    {m}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs leading-5 text-muted-foreground">
              این فقط یک مرجع شخصی است و اپلیکیشن ادعای فقهی خاصی ندارد.
            </p>
          </CardContent>
        </Card>

        {/* Submit */}
        <Button
          type="submit"
          size="lg"
          className="w-full"
          disabled={!isTotalValid}
        >
          شروع مسیر
          <ChevronLeft className="size-4" />
        </Button>
      </form>
    </div>
  );
}
