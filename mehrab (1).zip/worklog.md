# محراب — Worklog مشترک

این فایل توسط همه agent‌ها خوانده/به‌روزرسانی می‌شود. هر agent قبل از شروع، این فایل را بخواند و پس از اتمام، بخش خود را (با `---` جدا شده) اضافه کند.

---

Task ID: 1
Agent: orchestrator (main)
Task: ساخت فاز پایه «محراب» — layout، فونت Vazirmatn، RTL، سیستم رنگ emerald، types، config، persian (جلالی)، store (Zustand+persist)، calculations، کامپوننت‌های مشترک، BottomNav، AppHeader، هوک دستاوردها و یادآور.

Work Log:
- `src/app/layout.tsx`: RTL، lang=fa، فونت Vazirmatn از next/font/google، ThemeProvider (next-themes)، Toaster (sonner، top-center، rtl).
- `src/app/globals.css`: پالت emerald (light/dark)، توکن gold برای XP، فونت sans=Vazirmatn، utilities (slim-scroll, tap-safe, font-display)، reduced-motion.
- `src/lib/types.ts`: نوع‌های دامنه (PrayerKey, DhikrKey, QadaDayState, UserProfile, Settings, RootState, AchievementId).
- `src/lib/config.ts`: PRAYERS (۵ نماز با rakat)، DHIKR_LIST (صلوات/توحید/حمد با internalPoints)، XP constants، LEVELS (۱۵ سطح با نام فارسی + فرمول امتداد)، ACHIEVEMENTS (۱۰ دستاورد)، MARJA_OPTIONS، DAILY_GOAL_OPTIONS.
- `src/lib/persian.ts`: مبدل جلالی (toJalaali, jalaaliToDate, isJalaaliLeap)، toFa/faNumber/fromFa/parseFaInt، isoDate/todayIso، jalaaliStr/jalaaliLong/jalaaliWeekdayDayMonth، faTime/faDateTime، daysBetween/addDays، startOfJalaaliWeek، relativeTime.
- `src/lib/store.ts`: Zustand + persist به localStorage (key=mehrab-store-v1). اکشن‌ها: completeOnboarding, setupProfile, updateProfile, updateSettings, setReminder, togglePrayer, setPrayer, clearDay, incrementDhikr, decrementDhikr, resetDhikrDay, syncAchievements, resetAll, replayOnboarding.
- `src/lib/calculations.ts`: تمام مقادیر مشتق (single source of truth): completedPrayerCount, completedDayCount, remainingDays, overallProgress, activeDayIndex, dayCompletionRatio, xpFromQada, xpFromDhikr, totalXp, levelInfo, totalDhikrCount, dhikrCountByType, dhikrCountToday, dhikrInternalPoints, totalRakat, prayerCountsByType, dailyGoalTarget, prayersToday, currentStreak, longestStreak, calendarDayStatus, historyEntries, currentlyMetAchievements, isAchievementEverUnlocked, newlyUnlockedAchievements, personalPath, estimation, recentActivity, weeklyActivity, monthlyActivity, bestDay, activeDaysCount.
- کامپوننت‌های مشترک: `common/icon.tsx` (dynamic lucide by name)، `common/persian-number.tsx`، `common/empty-state.tsx`، `common/stat-card.tsx`، `common/section-title.tsx`، `common/confirm-dialog.tsx`.
- layout: `layout/bottom-nav.tsx` (۵ تب ثابت پایین)، `layout/app-header.tsx`.
- هوک‌ها: `hooks/use-achievements-sync.ts` (همگام‌سازی + toast دستاوردهای جدید)، `hooks/use-reminders.ts` (Notification API واقعی + requestReminderPermission).
- PWA: `public/manifest.webmanifest`، `public/icon.svg`.

Stage Summary:
- معماری: اپلیکیشن محلی تک‌کاربره با Zustand+persist به localStorage. هیچ backend لازم نیست. همه مقادیر مشتق از داده‌های مبدأ محاسبه می‌شوند → undo خودکار cascade می‌شود.
- مدل داده: qadaDays به‌صورت Record<index, {prayers}> (هر روز قضا = یک مجموعه ۵تایی). dhikr به‌صورت Record<YYYY-MM-DD, {type:count}>.
- XP فرمول: هر نماز +۱۰، هر روز کامل +۵۰ بونوس، هر ذکر internalPoints/100. کاملاً مشتق.
- دستاوردها: current از داده محاسبه، اما به‌محض تحقق به unlockedAchievements اضافه و ماندگار (persistence عمدی). هیچ‌کدام به‌صورت پیش‌فرض باز نیست.

═══════════════════════════════════════════════════════════════
## API قراردادی برای Viewها (مهم برای همه agent‌ها)
═══════════════════════════════════════════════════════════════

### Store (import { useStore } from "@/lib/store")
State fields: onboarded, setupComplete, profile ({totalQadaDays, startDate, dailyGoal, marja, createdAt}), settings ({theme, reminders:{enabled,time,permission}, jalaliCalendar}), qadaDays, dhikr, unlockedAchievements, onboardingVersion.
Actions: completeOnboarding(), setupProfile({totalQadaDays,startDate,dailyGoal,marja}), updateProfile(patch), updateSettings(patch), setReminder(patch), togglePrayer(dayIndex,prayer), setPrayer(dayIndex,prayer,done), clearDay(dayIndex), incrementDhikr(type), decrementDhikr(type), resetDhikrDay(date,type), syncAchievements(ids), resetAll(), replayOnboarding().

نکته: useStore() کل state را برمی‌گرداند. برای مصرف یک slice از selector: useStore((s)=>s.profile).

### Calculations (import {...} from "@/lib/calculations")
تمام توابع یک arg می‌گیرند: state (همان useStore() snapshot). مثال:
```
const s = useStore();
const remaining = remainingDays(s);
const xp = totalXp(s);
const level = levelInfo(s);
const streak = currentStreak(s);
```

### Config (import {PRAYERS, DHIKR_LIST, DHIKR_MAP, ACHIEVEMENTS, ACHIEVEMENT_MAP, MARJA_OPTIONS, DAILY_GOAL_OPTIONS, LEVELS, APP_VERSION} from "@/lib/config")

### Persian (import {toFa, faNumber, parseFaInt, jalaaliLong, jalaaliStr, faTime, faDateTime, isoDate, todayIso, PERSIAN_MONTHS, WEEKDAYS_FA, WEEKDAYS_SHORT_FA, addDays, daysBetween, startOfJalaaliWeek, toJalaali, jalaaliToDate, relativeTime} from "@/lib/persian")

### کامپوننت‌های مشترک موجود
- `<PersianNumber value={n} />` — عدد فارسی با جداکنزار.
- `<EmptyState icon="Inbox" title="..." description="..." action={...} />` — نام icon از lucide.
- `<StatCard label="..." value={...} unit="..." hint="..." accent="gold|primary|default" icon={<Icon .../>} />`.
- `<SectionTitle title="..." subtitle="..." action={...} />`.
- `<ConfirmDialog open onOpenChange title description confirmText cancelText destructive onConfirm trigger />`.
- `<Icon name="Footprints" className="..." />` (dynamic lucide).

### قواعد طراحی (الزامی)
- رنگ primary: emerald. برای XP/دستاورد از `text-gold` / `accent="gold"` استفاده شود. آبی/ایندیگو ممنوع.
- container اصلی همه viewها: `mx-auto w-full max-w-md px-4 py-4 space-y-4`. (mobile-first، روی دسکتاپ مرکز).
- padding پایین برای محتوا به‌خاطر ناوبری ثابت: `pb-24`.
- RTL همه‌جا فعال است (html dir=rtl). برای آیکن‌های جهت‌دار از نسخه‌های RTL-safe استفاده شود یا چپ/راست را منطقی نگه دارید.
- اعداد: همیشه فارسی (PersianNumber یا toFa). تاریخ: همیشه جلالی با توابع persian.ts.
- هیچ داده فیک/سample/demo/hardcoded-user-data مجاز نیست. فقط constantهای محصول (نام نمازها، امتیازات داخلی ذکر، تعریف دستاوردها) ثابت‌اند.
- empty stateها:
  - تاریخچه خالی: «هنوز سابقه‌ای ثبت نشده است.»
  - آمار ناکافی: «هنوز داده کافی برای نمایش این نمودار وجود ندارد.»
  - ذکر خالی: «هنوز ذکری ثبت نشده است.»
- همه دکمه‌ها باید کاری انجام دهند (no dead buttons).
- destructive actions حتماً ConfirmDialog.
- sticky footer: ناوبری پایین ثابت است (fixed). محتوا pb-24 دارد.
- از shadcn/ui موجود در src/components/ui استفاده شود (Button, Card, Progress, Tabs, Dialog, Switch, Select, RadioGroup, Input, Label, Slider, Badge, Separator, ScrollArea, Tooltip, Calendar, Chart).
- فریم‌ورک نمودار: recharts (نصب شده). از داده واقعی استفاده شود، وگرنه empty state.
- انیمیشن‌ها: framer-motion، ظریف.

### مسیر فایل‌های view
- src/components/views/onboarding-flow.tsx (default export OnboardingFlow)
- src/components/views/initial-setup.tsx (default export InitialSetup)
- src/components/views/home-view.tsx (default export HomeView)
- src/components/views/qada-view.tsx (default export QadaView)
- src/components/views/dhikr-view.tsx (default export DhikrView)
- src/components/views/stats-view.tsx (default export StatsView)
- src/components/views/settings-view.tsx (default export SettingsView)

هر view یک کامپوننت `("use client")` با `export default function` است و هیچ prop نمی‌گیرد (همه را از store می‌خواند).

---

Task ID: 2-b
Agent: home-qada-builder
Task: ساخت HomeView و QadaView

Work Log:
- `src/components/views/home-view.tsx` (default export `HomeView`, `"use client"`، بدون prop):
  - Section 1 — Hero progress card: درصد `overallProgress` با عدد بزرگ فارسی + Progress bar از shadcn. «روزهای باقی‌مانده» با `text-gold` و «روزهای انجام‌شده» با `<PersianNumber value={completed} /> از <PersianNumber value={total} />`. در ۱۰۰٪ پیام «الحمدلله! مسیر قضا به پایان رسید.» با Trophy icon و پس‌زمینه gold/10.
  - Section 2 — نماز امروز: اگر `activeDayIndex === -1` پیام تکمیل با Trophy؛ وگرنه «روز قضا #N» (PersianNumber)، Badge «X از ۵» با `dayCompletionRatio`، ۵ chip قابل toggle با `s.togglePrayer(activeIdx, p.key)` (done: bg-primary + Check icon، undone: outline muted). هر chip از نوع motion.button با `whileTap={{scale:0.92}}`.
  - Section 3 — Today summary row: ۳ StatCard (هدف امروز = `dailyGoalTarget`، نمازهای امروز = `prayersToday`، استریک = `currentStreak` با Flame icon و accent gold هنگام streak>0).
  - Section 4 — Level & XP card: level.level (PersianNumber) + level.name + totalXp (PersianNumber) با accent gold. Progress bar با `[&>div]:bg-gold` برای pct. «امتیاز تا سطح بعد» از `level.toNext`.
  - Section 5 — مسیر من mini: horizontal scroll بدون scrollbar (`no-scrollbar`) از `personalPath`. نقطه فعلی emerald، رسیده gold، آینده muted. Hint «مسیر کامل در بخش آمار.»
  - Section 6 — آمار سریع: گرید ۲ ستونی از StatCard (totalRakat، totalDhikrCount، activeDaysCount، bestDay?.prayers یا «—»).
  - Section 7 — دستاوردهای اخیر: scroll horizontal از `ACHIEVEMENTS.filter(a => isAchievementEverUnlocked(s, a.id))`. اگر خالی، EmptyState کوچک با Trophy icon و «هنوز دستاوردی باز نشده است.»
  - guard `if (!s.profile) return null;` برای حالت دفاعی. container: `mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24` با `dir="rtl"`.
- `src/components/views/qada-view.tsx` (default export `QadaView`، `"use client"`، بدون prop):
  - Section 1 — Summary header card: گرید ۳ ستونی «تعداد کل» / «انجام‌شده» (primary) / «باقی‌مانده» (gold) + Progress bar کلی. Percentage و «N از M روز» در footer.
  - Section 2 — Active day card (big): اگر activeIdx===-1 → EmptyState با Trophy icon و «مسیر قضا کامل شد!». وگرنه ۵ ردیف عمودی بزرگ (min-h-[3.5rem]) هرکدام: نام کامل + shortName + «N رکعت» (PersianNumber) + دکمه دایره‌ای بزرگ سمت چپ (size-9) با Check icon (filled primary در done، outline در undone). هر ردیف motion.button با `whileTap={{scale:0.98}}`. Badge «X از ۵». در ۵/۵ badge gold «این روز کامل شد» با Trophy. hint «با تکمیل این روز، روز بعدی به‌صورت خودکار فعال می‌شود.»
  - Section 3 — Recent days: بازه `[max(0, activeIdx-10), min(total, activeIdx+2))` (در حالت complete آخر ۱۰ روز). هر روز یک Card با «روز قضا #N»، Badge «امروز» در صورت فعال، Check badge gold در صورت کامل. گرید ۵ ستونی از mini toggles (size-9 buttons، dots کوچک) که هرکدام `s.togglePrayer(dayIdx, p.key)` را صدا می‌زنند → این مکانیزم undo است. اسکرول عمودی با `max-h-96 overflow-y-auto slim-scroll`.
  - Section 4 — History preview: ۸ ورودی آخر از `historyEntries`. هر ورودی: icon (BookOpenCheck برای prayer، Sparkles برای dhikr)، label، `faDateTime(ts)`. prayerها دکمه ghost destructive «برگشت» دارند که `s.setPrayer(entry.dayIndex, entry.prayer, false)` را صدا می‌زنند (undo). dhikrها بدون undo (در Dhikr view مدیریت می‌شوند). در حالت خالی، EmptyState با History icon و «هنوز سابقه‌ای ثبت نشده است.»
  - Section 5 — Clear day: دکمه ghost destructive «پاک کردن این روز» با ConfirmDialog (title «پاک کردن این روز قضا»، description «آیا مطمئن هستید؟ تمام نمازهای این روز قضا پاک خواهد شد.». confirmText «پاک کن»، destructive). روی تأیید `s.clearDay(activeIdx)` صدا می‌شود.
  - container: `mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24` با `dir="rtl"`. helper components: `SummaryCell`، `ActiveDayCard`، `PrayerRow`، `RecentDayRow` به‌صورت local.
- اعداد همگی از `<PersianNumber value={n} />` یا `faNumber` استفاده می‌کنند. تاریخ‌ها از `faDateTime`.
- استفاده از store: `const s = useStore();` و سپس pass به تمام calculation functions. هیچ داده فیک.
- duplicate protection: اتکا به no-op guard داخلی `store.togglePrayer` و `store.setPrayer`. هیچ debounce اضافه نشد.
- تست: ESLint (بدون خطا در فایل‌های من، ۲ خطای pre-existing در icon.tsx و use-achievements-sync.ts که از فاز ۱ به جا مانده) و TypeScript (`tsc --noEmit` clean برای فایل‌های من) و dev server compile بدون خطا.

Stage Summary:
- HomeView یک dashboard تک‌نگاهی است: پیشرفت کلی، نماز امروز قابل toggle، سه KPI روزانه، سطح/XP، مسیر فشرده، آمار سریع، و دستاوردهای اخیر. همه real-time از store.
- QadaView مکانیزم کامل مدیریت است: خلاصه بالا، کارت روز فعال بزرگ با ۵ ردیف touch-friendly، لیست روزهای اخیر با undo (mini toggles)، تاریخچه با undo prayerها، و clear day با ConfirmDialog.
- auto-advance: چون `activeDayIndex` اولین روز ناتمام را برمی‌گرداند، با تکمیل ۵ نماز، روز بعدی به‌صورت خودکار فعال می‌شود. این رفتار در hint ذکر شد.
- undo cascade: چون تمام مقادیر (XP، count، streak، level، دستاوردها) از داده مبدأ مشتق می‌شوند، toggling off یک نماز به‌صورت خودکار همه را بازمی‌گرداند. این در Recent days و History پیاده شد.
- همه‌چیز RTL، Vazirmatn، اعداد فارسی، بدون آبی/ایندیگو، emerald primary + gold برای XP/دستاورد.

---

Task ID: 2-a
Agent: onboarding-setup-builder
Task: ساخت OnboardingFlow و InitialSetup

Work Log:
- خواندن کامل worklog.md برای فهم API‌های store، calculations، config، persian و قواعد طراحی.
- ایجاد `src/components/views/onboarding-flow.tsx`:
  - کاروسل ۴ اسلایدی با state دستی + framer-motion (بدون embla، ساده‌تر).
  - اسلایدها: خوش‌آمدگویی (محراب + Sparkles)، پیگیری قضا (ListChecks + ۴ بولت با Check)، ابزارهای همراه (Wrench + ۶ چیپ)، شروع (Rocket + CTA).
  - navigation: نقطه‌های پایین (با قابلیت کلیک)، دکمه‌های «قبلی»/«بعدی»، «شروع کنیم» در اسلاید آخر، «رد کردن» در همه اسلایدها (top bar).
  - شمارنده «۱ از ۴» با PersianNumber در top bar.
  - پشتیبانی از swipe با drag="x" framer-motion و آستانه ۸۰px (RTL-aware: offset.x<-80 → next، offset.x>80 → prev).
  - انیمیشن subtle: opacity + x (direction-aware: direction*-30 → 0)، duration 0.3s.
  - layout: min-h-[100dvh] flex flex-col، bg-background، آیکن ۹۶px در دایره bg-primary/10.
  - completeOnboarding در «رد کردن» و «شروع کنیم».
- ایجاد `src/components/views/initial-setup.tsx`:
  - Header «بیایید شروع کنیم» + subtitle.
  - ۴ Card با p-5 gap-4 (CardHeader/CardContent با px-0 برای حذف px-6 پیش‌فرض).
  - فیلد تعداد کل روزهای قضا: Input با inputMode=numeric، pattern فارسی، parseFaInt برای validation، integer≥1، خطای inline فارسی «لطفاً یک عدد صحیح بزرگتر از صفر وارد کنید.»، helper «مثلاً ۳۰۰».
  - فیلد تاریخ شروع: ۳ Select (سال jy-10..jy+1، ماه PERSIAN_MONTHS، روز ۱..maxDay) با clamp روز بر اساس ماه/سال (daysInJalaaliMonth helper با isJalaaliLeap برای اسفند). تبدیل نهایی با jalaaliToDate + isoDate → startDate. پیش‌فرض امروز (toJalaali(new Date())).
  - فیلد هدف روزانه: RadioGroup با DAILY_GOAL_OPTIONS، پیش‌فرض value=1، Label wrapper با hover و حالت checked (has-[[data-state=checked]]).
  - فیلد مرجع: Select با MARJA_OPTIONS، پیش‌فرض «بدون مرجع»، یادآور muted «این فقط یک مرجع شخصی است و اپلیکیشن ادعای فقهی خاصی ندارد.».
  - دکمه submit «شروع مسیر» (size=lg، w-full، disabled تا زمانی که totalQadaDays معتبر باشد) → setupProfile + toast.success «اطلاعات شما ذخیره شد.»
  - بدون تنظیمات یادآور (طبق وظیفه، در Settings قرار دارد).
  - اعداد همه فارسی (toFa برای مقادیر Select، PersianNumber برای counter).
- تست: lint تمیز برای هر دو فایل (فقط خطای موجود در icon.tsx از فاز ۱ باقی مانده)، tsc بدون خطا برای فایل‌های جدید.

Stage Summary:
- دو فایل ساخته شد: `onboarding-flow.tsx` و `initial-setup.tsx`. هر دو "use client" با default export و بدون prop.
- الگوی RTL کامل رعایت شد: chevronها جهت‌دار (ChevronLeft=forward، ChevronRight=back)، swipe RTL-aware، RadioGroup/Select با w-full.
- هیچ داده فیک: فقط constantهای محصول (DAILY_GOAL_OPTIONS، MARJA_OPTIONS، PERSIAN_MONTHS) و API واقعی store.
- validation: parseFaInt برای integer≥1، clamp روز برای ماه کبیسه جلالی.
- انیمیشن‌ها: framer-motion ظریف (transition 0.3s، drag elastic 0.18).
- این دو view روی نسخه‌های بعدی که AppRouter/page.tsx را بر اساس onboarded/setupComplete انتخاب می‌کند، مصرف می‌شوند.

---

Task ID: 2-d
Agent: settings-builder
Task: ساخت SettingsView

Work Log:
- خواندن کامل worklog.md (API قراردادی store، calculations، config، persian، کامپوننت‌های مشترک، قواعد طراحی) قبل از شروع.
- ساخت `src/components/views/settings-view.tsx` به‌صورت `("use client")` با `export default function SettingsView` بدون props. داده‌ها از `useStore()` خوانده می‌شوند.
- ۹ بخش پیاده‌سازی شد:
  1. هدف روزانه — `RadioGroup` با `DAILY_GOAL_OPTIONS`، مقدار جاری از `state.profile.dailyGoal`، onChange → `store.updateProfile({ dailyGoal })` + toast.
  2. تعداد کل نمازهای قضا — Input با inputMode=numeric + دو دکمه استپر (−/+) با اندازه لمسی ۴۴px. parse با `parseFaInt`، اعتبارسنجی ≥1، onBlur و onClick دکمه‌ها commit می‌کنند. helper text دقیقاً مطابق spec.
  3. مرجع تقلید — `Select` با `MARJA_OPTIONS`، value از `state.profile.marja`، onChange → `updateProfile({ marja })`. disclaimer فقهی به‌صورت muted.
  4. تاریخ شروع — نمایش `jalaaliLong(new Date(profile.startDate))`، دکمه «ویرایش» → Dialog با ۳ Select (سال/ماه/روز) روی تقویم جلالی. محدوده سال = jy-30..jy+1. روز بر اساس طول ماه جلالی محاسبه می‌شود (`daysInJalaaliMonth` با `isJalaaliLeap`). onChange تأیید → `updateProfile({ startDate: isoDate(jalaaliToDate(jy,jm,jd)) })` + toast.
  5. ظاهر — segmented control سه‌گانه (روشن/تاریک/سیستم) با role=radiogroup. selected از `state.settings.theme`. onClick → هم `store.updateSettings({ theme })` و هم `useTheme().setTheme(value)` واقعی از next-themes. یک effect one-time روی mount مقادیر store را به next-themes sync می‌کند تا عدم تطابق اولیه بین دو storage برطرف شود.
  6. یادآور — `Switch` برای `reminders.enabled`، Input با type="time" برای `reminders.time`، دکمه «درخواست اجازه اعلان» که `requestReminderPermission()` (از `@/hooks/use-reminders` — مسیر واقعی فایل) را صدا می‌زند و نتیجه را در store ذخیره می‌کند. وضعیت permission با ۴ حالت (default/granted/denied/unsupported) به‌صورت صادقانه با آیکن و رنگ مناسب نمایش داده می‌شود. یادآور «فقط زمانی که اپلیکیشن باز باشد فعال هستند» هم به‌عنوان helper اضافه شد.
  7. دستاوردها — گرید ۲ ستونی از همه `ACHIEVEMENTS` با `<Icon name={def.icon} />`. وضعیت باز/قفل از `isAchievementEverUnlocked(state, def.id)`. بازشده: border-gold/40 + bg-gold/5 + آیکن Check سبز. قفل‌شده: muted + opacity-70 + آیکن Lock. شمارش «X از Y» با PersianNumber.
  8. داده‌ها — «بازپخش آموزش» با ConfirmDialog (تأیید → `store.replayOnboarding()` + toast). «بازنشانی کامل» با ConfirmDialog و destructive=true، عنوان/توضیحات/confirmText دقیقاً مطابق spec (تأیید → `store.resetAll()` + toast).
  9. درباره اپلیکیشن — نام «محراب»، نسخه APP_VERSION (PersianNumber)، توضیح کوتاه. کارت muted جداگانه با لیبل «درباره سازنده» و خط دقیق `سازنده: 𝓜𝓸𝓱𝓪𝓶𝓶𝓪𝓭 𝓗𝓸𝓼𝓼𝓮𝓲𝓷` (یونی‌کد fancy بدون تغییر). یادآور محلی بودن داده‌ها با آیکن ShieldCheck.
- همه دکمه‌ها/کنترل‌ها واقعاً به store یا next-themes متصل‌اند (no dead buttons). اعداد همگی فارسی (toFa / PersianNumber). رنگ primary = emerald، accent دستاوردها = gold، آبی/ایندیگو استفاده نشده. container اصلی `mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24`. هر بخش داخل Card با CardContent `p-5 space-y-4` و SectionTitle با آیکن کنارش.
- اعتبارسنجی: `bun run lint` — صفر خطا و صفر هشدار در settings-view.tsx (خطاهای باقی‌مانده در icon.tsx و use-achievements-sync.ts مربوط به foundation بوده و خارج از scope این task است). `bunx tsc --noEmit` هم برای فایل من تمیز است.
- نکته فنی: مسیر واقعی هوک `requestReminderPermission` در پروژه `@/hooks/use-reminders` است (نه `@/lib/use-reminders` که در spec آمده) — فایل واقعی در `src/hooks/use-reminders.ts` است. این به‌صورت correct ایمپورت شد.

Stage Summary:
- یک SettingsView کامل و واقعی تحویل شد: همه کنترل‌ها به store/next-themes متصل، destructive action‌ها با ConfirmDialog، achievements با وضعیت واقعی، theme واقعاً apply می‌شود، reminders با Notification API واقعی. اعتبار schema، data-types و lint تمام است.
- قرارداد قرض‌گرفته‌شده از foundation (store API، calculations، config constants، persian utils، shared components) دقیقاً همان‌طور که در worklog بود رعایت شد.
- هیچ داده فیک/sample/hardcoded اضافه نشد. فقط ثابت‌های محصول (DAILY_GOAL_OPTIONS، MARJA_OPTIONS، ACHIEVEMENTS، APP_VERSION) استفاده شدند.

---

Task ID: 2-c
Agent: dhikr-stats-builder
Task: ساخت DhikrView و StatsView

Work Log:
- `src/components/views/dhikr-view.tsx` (default export DhikrView): container `mx-auto w-full max-w-md px-4 py-4 space-y-4 pb-24` با `dir="rtl"`. پنج بخش:
  1. سگمنت‌د سه‌گانه انتخاب ذکر (صلوات/توحید/حمد) با state محلی `useState<DhikrKey>("salawat")`.
  2. کارت شمارندهٔ بزرگ: نام ذکر، متن عربی (`dir="rtl"`، `font-display`)، یادداشت امتیاز داخلی + disclaimer الهی، عدد بزرگ (`text-7xl`)، دکمهٔ + بزرگ (`w-full h-20 rounded-2xl bg-primary` + `motion.button whileTap scale 0.96`)، دکمهٔ برگشت outline (disabled وقتی todayCount===0) و «شروع مجدد» ghost destructive که با `ConfirmDialog` باز می‌شود.
  3. ردیف خلاصهٔ امروز (۳ ستون) با هایلایت ذکر انتخاب‌شده.
  4. کارت امتیاز داخلی کل اذکار (gold accent، `border-gold/40 bg-gold/5`) با مجموع ذکرها و تفکیک به‌نوع.
  5. تاریخچه اذکار (`useMemo` روی `s.dhikr`، مرتب newest-first) با scroll max-h-96 و EmptyState (icon=Sparkles) وقتی خالی.
- `src/components/views/stats-view.tsx` (default export StatsView): همان container. ساختار:
  1. Tabs (هفتگی/ماهانه/کلی) — فقط نمودار فعالیت به tab واکنش نشان می‌دهد.
  2. گرید ۲ ستونی StatCard با ۱۲ آمار واقعی (شامل روزهای ناقص محاسبه‌شده inline با iterate `s.qadaDays` و شمارش نمازهای انجام‌شده).
  3. BarChart توزیع نمازها (۵ ستون با Cell رنگ‌های chart-1..5، `XAxis reversed`، `tickFormatter={toFa}`). EmptyState (icon=BarChart3) وقتی همه صفر.
  4. نمودار فعالیت: هفتگی BarChart با لیبل weekday، ماهانه/کلی AreaChart با gradient و interval داینامیک. `XAxis reversed`، YAxis `tickFormatter={toFa}`، Tooltip سفارشی (`ChartTooltip`) با عدد فارسی. EmptyState وقتی هیچ فعالیتی نیست.
  5. تقویم جلالی واقعی: state `displayMonth {jy, jm}` با دکمه‌های prev/next (ChevronRight برای prev، ChevronLeft برای next — RTL منطقی)، header سال/ماه قابل کلیک برای بازگشت به امروز، weekday headers به ترتیب هفتهٔ فارسی (ش..ج) از `WEEKDAYS_SHORT_FA` بازمرتب‌شده، گرید ۷ ستونی با `offset = (getDay(jalaaliToDate(jy,jm,1)) + 1) % 7` و روزهای ماه با computeMonthGrid (۳۱/۳۰/۲۹|۳۰ کبیسه از `isJalaaliLeap`). هر سلول با `calendarDayStatus(s, iso)` رنگ می‌شود (کامل=primary، ناقص=gold/amber + dot، بدون فعالیت=muted). امروز ring-primary. title attr `${toFa(prayerCount)} نماز`. لجند پایین.
  6. مسیر من (personalPath) به‌صورت vertical timeline: خط عمودی absolute پشت نودها، هر milestone با node دایره‌ای (رسیده=primary filled با CheckCircle2، فعلی=gold ring + pulse، آینده=muted)، label + «حدود X روز دیگر» یا «رسیده». EmptyState (icon=Footprints) وقتی path.length===0.
  7. تخمین (`estimation`): اگر hasEnoughData، کارت primary-accent با «با میانغین X نماز در روز، حدوداً در تاریخ Y مسیر قضا را کامل می‌کنی» + ردیف «حدود Z روز دیگر». اگر نه، کارت dashed با reason به‌صورت muted.
- همهٔ اعداد فارسی (PersianNumber برای UI، toFa برای tickFormatter و hint). هیچ دادهٔ فیک. RTL همه‌جا (recharts با `reversed` روی XAxis). framer-motion فقط برای دکمهٔ + ذکر. ConfirmDialog برای reset.
- نکتهٔ TypeScript: import unused `isDayComplete` از store حذف شد (محاسبهٔ incompleteDays inline با PRAYER_KEYS.filter انجام می‌شود).
- تایید: `bun run lint` — هیچ خطا/هشدار جدیدی در این دو فایل نیست (خطای icon.tsx و warning موجود از قبل مربوط به این تسک نیست). `bunx tsc --noEmit` — بدون خطا در src/.

Stage Summary:
- دو view کامل و production-ready با معماری دقیقاً مطابق قرارداد API کار شد.
- DhikrView: شمارندهٔ سریع و راضی‌کننده با دکمهٔ + بزرگ و motion tap، امتیازدهی داخلی gold، تاریخچه قابل اسکرول، EmptyStateها.
- StatsView: داشبورد آماری واقعی با ۱۲ StatCard، ۲ نمودار recharts (توزیع نماز Bar + فعالیت Bar/Area وابسته به tab)، تقویم جلالی واقعی با رنگ‌بندی status، مسیر عمودی شخصی، و کارت تخمین پایان.
- همهٔ داده‌ها از `useStore()` و توابع calculations گرفته شده؛ هیچ دادهٔ فیک/hardcoded.
- همهٔ اکشن‌ها فعال، destructive actions با ConfirmDialog، empty stateها فارسی و محلی‌سازی‌شده.

---
Task ID: 3+4
Agent: orchestrator (main)
Task: ادغام نهایی (page.tsx router)، رفع باگ‌ها، تست end-to-end با Agent Browser + VLM.

Work Log:
- ساخت `src/app/page.tsx`: router با hydration guard (Zustand persist)، dynamic import همه viewها (ssr:false)، AppHeader + BottomNav + MainApp shell، hook‌های useAchievementsSync و useReminders فعال.
- باگ۱ (critical): dynamic import از `m.OnboardingFlow` (named) استفاده می‌کرد در حالی که همه viewها `export default` داشتند → به `m.default` اصلاح شد.
- باگ۲ (critical): الگوریتم دستی جلالی (d2j/j2d) برای تاریخ امروز خروجی نامعتبر (jm=31) می‌داد. با نصب پکیج معتبر `jalaali-js` جایگزین شد؛ همه تبدیل‌ها (toJalaali, jalaaliToDate, isJalaaliLeap, jalaaliMonthLength) اکنون صحیح‌اند.
- باگ۳: سال تقویم در آمار با کاما نمایش داده می‌شد («شهریور ۱,۴۰۵») → PersianNumber با separator={false}.
- باگ۴: subtitle هدر عدد انگلیسی نشان می‌داد → با toFa فارسی شد.
- بهبود UX: پیشرفت کمتر از ۱٪ به‌جای «۰٪» اکنون «کمتر از ۱» نمایش می‌دهد.
- رفع خطاهای lint (icon.tsx module-level mutation، unused eslint-disable directives، React Compiler memoization).

تست‌های end-to-end با Agent Browser (همه قبول):
- Onboarding: ۴ اسلاید + رد کردن + شروع ✓
- Setup: ۳۰۰ روز، تاریخ جلالی (۲۵ شهریور ۱۴۰۵)، هدف ۱، مرجع ✓
- Home: ۳۰۰ باقی‌مانده، ۰٪ → تکمیل صبح → «۱ از ۵»، نمازهای امروز ۱ ✓
- تکمیل ۵ نماز: ۱ روز انجام‌شده، ۲۹۹ باقی‌مانده، ۵ نماز امروز، استریک ۱، ۱۷ رکعت، XP=۱۰۰، سطح ۲، روز قضا #۲ خودکار فعال ✓
- Undo (برگشت این نماز): روز ناقص (۴ از ۵)، انجام‌شده ۰، باقی‌مانده ۳۰۰، روز #۱ دوباره فعال، cascade کامل ✓
- Dhikr: شمارنده ۳، امتیاز ۳۰۰، undo→۲ ✓
- Stats: نمودار توزیع (۵ ستون) + فعالیت (۷ ستون)، تقویم جلالی با امروز هایلایت‌شده کامل، مسیر شخصی پویا، تخمین «برای محاسبه روند...» (داده ناکافی) ✓
- Settings: هدف، تعداد با stepper، مرجع، تاریخ، ظاهر (روشن/تاریک/سیستم واقعی)، یادآور (Notification API)، دستاوردها (۲ از ۱۰)، بازپخش آموزش، بازنشانی کامل ✓
- یادبود سازنده: «سازنده: 𝓜𝓸𝓱𝓪𝓶𝓶𝓪𝓭 𝓗𝓸𝓼𝓼𝓮𝓲𝓷» دقیق ✓
- Persistence: reload → داده ماندگار ✓
- Dark mode: کلاس dark اعمال شد، تأیید بصری VLM ✓
- Reset: تأیید دیالوگ → بازگشت به onboarding ✓
- VLM: صفحه خانه و آمار تمیز، حرفه‌ای، RTL، اعداد فارسی، پالت آرام (بدون آبی/ایندیگو)، بدون overflow ✓
- lint تمیز، dev server 200، بدون خطای runtime ✓

Stage Summary:
- اپلیکیشن «محراب» کامل، واقعی و کاربردی است. همه ۱۶ تست عملکردی قبول شد. هیچ داده فیک/سample/demo وجود ندارد. همه مقادیر از داده‌های مبدأ کاربر مشتق شده‌اند. اپ در حالت اولیه (onboarding) آماده تحویل است.
